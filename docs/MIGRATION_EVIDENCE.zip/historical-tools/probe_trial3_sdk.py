import inspect, dis, json
import prepare_trial as p
from garrison_shared import mod_project, derived_blueprints
print('DERIVE',inspect.signature(mod_project.derive_blueprint))
print('BUILD',inspect.signature(derived_blueprints.build))
for mod in (mod_project,derived_blueprints):
 print(mod.__name__,[(k,str(inspect.signature(v))) for k,v in vars(mod).items() if inspect.isfunction(v) and any(s in k.lower() for s in ('pbg','ident','derive','cook','allocate'))])
print('DERIVE CODE')
dis.dis(mod_project.derive_blueprint)
print('BUILD CODE')
dis.dis(derived_blueprints.build)
print('CONTRIBUTION CODE')
dis.dis(mod_project._derived_contribution)
