import json
import prepare_trial as p
base=p.ROOT/'output/dropdown-fix/build/readback'
report={}
for f in (base/'attrib/attachments').rglob('*.rgd'):
 if any(t in f.stem for t in ('town','villager','scout')):
  d=p.rgd.read(f.read_bytes());report[f.relative_to(base).as_posix()]=[(q,n.kind,n.value) for q,n in p.rgd.flatten(d.nodes) if q.startswith('default/') and not isinstance(n.value,list)]
p.save(p.ROOT/'output/trial3-audit/starting-attachments.json',report)
print('ALL FAMILY NAMES',[(p.key(f.relative_to(base).as_posix()),f.stat().st_size) for f in (base/'attrib/attachments').rglob('*.rgd')])
print('STARTING',json.dumps(report,indent=2)[:12500])
