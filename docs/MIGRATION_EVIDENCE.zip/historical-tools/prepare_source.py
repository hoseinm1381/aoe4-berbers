"""One-time audited extraction of the owner-tested trial into portable inputs.

Run before retiring experimental output. Never modifies the original project.
"""
import hashlib
import shutil
import zipfile
from pathlib import Path
from runtime import ROOT, read_json, write_json, export_table, import_table


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    report = read_json(ROOT / 'output/trial3/current/report.json')
    base = Path(report['readback'])
    recipe = read_json(ROOT / 'trial3-build-recipe.json')
    out = ROOT / 'inputs'
    out.mkdir(exist_ok=True)
    target = out / 'Berbers-native-inputs.zip'
    assert not target.exists(), target
    index = {}
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for member, row in report['members'].items():
            raw = (base / member).read_bytes()
            assert sha(raw) == row['sha256'], member
            index[member] = dict(row)
            if row['toc'] == 'attrib':
                data = export_table(raw)
                assert import_table(data) == raw, member
                write_json(ROOT / 'source/tables' / (member + '.json'), data)
            elif member.startswith('scar/'):
                source = ROOT / 'source/trial3' / member
                if member == recipe['dispatcher']:
                    assert raw.endswith(source.read_bytes()), member
                else:
                    assert raw == source.read_bytes(), member
                dest = ROOT / 'source' / member
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, dest)
            elif member.startswith(('en/', 'ui/')):
                dest = ROOT / 'source/resources' / member
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(raw)
            elif member == 'garrison/civilizations.json':
                continue
            else:
                z.writestr(member, raw)
    assert zipfile.ZipFile(target).testzip() is None
    write_json(ROOT / 'source/baseline-members.json', index)
    write_json(ROOT / 'project.json', {k: v for k, v in recipe.items() if k not in ('attributes', 'members')} | {
        'version': '0.1.0', 'bundle_key': 'berbers',
        'baseline_archive_sha256': report['sha256'],
        'baseline_archive_bytes': Path(report['archive']).stat().st_size,
        'native_inputs': 'inputs/Berbers-native-inputs.zip'})
    write_json(ROOT / 'docs/SOURCE_PREPARATION.json', {
        'baseline_archive_sha256': report['sha256'], 'members': len(index),
        'all_attribute_json_roundtrips_byte_identical': True,
        'owner_acceptance': 'Owner reports trial.3 loaded and worked on 2026-10-30; detailed test coverage unspecified.'})
    print('PORTABLE SOURCE PREPARED', len(index), target.stat().st_size, flush=True)


if __name__ == '__main__':
    main()
