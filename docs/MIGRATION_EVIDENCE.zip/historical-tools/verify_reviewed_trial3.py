"""Verify a fresh reviewed assembler output, its recipe, and immutable baseline."""
import collections,hashlib,json
from pathlib import Path
import prepare_trial as p
from check_native_metadata import require_metadata

def main():
 root=p.ROOT;build=root/'output/trial3/current'
 report=json.loads((build/'report.json').read_text())
 readback=Path(report.get('readback',str(build/'readback')))
 prior=json.loads((root/'output/dropdown-fix/build/report.json').read_text())
 recipe=json.loads((root/'trial3-build-recipe.json').read_text())
 archive=Path(report['archive']);expected=report['members']
 game=p.stock_game.current();listing=game.archiver.run(['list',str(archive),'--verify'])
 assert listing['archive']['name']==p.OWNER and listing['archive']['verification']['verified']
 actual={r['path']:r for r in listing['members']};assert set(actual)==set(expected)
 for m,row in expected.items():
  assert actual[m]['toc']==row['toc'],m
  assert p.sha((readback/m).read_bytes())==row['sha256'],m
 require_metadata(expected)
 for name in ('mod.bin','mod.rrtex'):assert expected[name]==prior['members'][name]
 for row in recipe['attributes']+recipe['members']:
  if row['member']==recipe['dispatcher']:
   assert (readback/row['member']).read_bytes().endswith(Path(row['file']).read_bytes())
  else:assert expected[row['member']]['sha256']==row['sha256'],row['member']
 preserved=[m for m in prior['members'] if m.startswith(('art/','audio/'))]
 for m in preserved:assert expected[m]==prior['members'][m],m
 # New Codex references must not introduce an unchecked stock dependency.
 def stockrefs(docs):
  return {(mp.value.replace('\\','/'),n.value) for d in docs for q,n,mp in p.refs(d.nodes) if ':' not in n.value}
 olddocs=[p.rgd.read((root/'output/dropdown-fix/build/readback'/m).read_bytes()) for m,r in prior['members'].items() if r['toc']=='attrib']
 newdocs=[p.rgd.read((readback/m).read_bytes()) for m,r in expected.items() if r['toc']=='attrib']
 newstock=stockrefs(newdocs);oldstock=stockrefs(olddocs)
 assert not newstock-oldstock,newstock-oldstock
 root_flags=[n.value for d in newdocs for q,n in p.rgd.flatten(d.nodes) if n.key=='override_instances']
 assert root_flags==[False],root_flags
 declaration=json.loads((readback/'garrison/civilizations.json').read_text())
 for entry in [declaration['attribute_root']]+declaration['races']+declaration['scripts']:
  assert entry['sha256']==expected[entry['member']]['sha256'],entry
 # Local Codex coordinates remain bounded by each native producer group.
 codex=next(d for m,d in zip([m for m,r in expected.items() if r['toc']=='attrib'],newdocs) if p.family(m)=='codex')
 groupmax=0
 for g in p.rgd.find(codex.nodes,'default/codex_bag/tech_tree').value:
  positions=[(p.child(it,'x_position').value,p.child(it,'y_position').value) for it in p.child(g,'items').value]
  assert len(positions)==len(set(positions)),positions
  groupmax=max(groupmax,max(abs(x) for x,y in positions))
 assert groupmax<=6,groupmax
 digest=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest();assert digest==report['sha256']
 assert hashlib.file_digest(Path(prior['archive']).open('rb'),'sha256').hexdigest()==prior['sha256']
 assert hashlib.file_digest(p.BASE.open('rb'),'sha256').hexdigest()=='55629909581fd0035a141f212e38274d3e1f7f185fecffed635b821e2b7204a6'
 receipt={'version':'0.1.0-trial.3','archive':str(archive),'archive_sha256':digest,
 'archive_bytes':archive.stat().st_size,'all_members_read_back':len(expected),'archive_crc_sha1_verified':True,
 'native_info_metadata_preserved':True,'baseline_art_audio_members_byte_identical':len(preserved),
 'recipe_members_checked':True,'new_unchecked_stock_refs':[], 'unique_stock_refs':len(newstock),
 'codex_max_absolute_local_x':groupmax,'trial2_rollback_sha256':prior['sha256'],
 'original_1_0_5_composed_archive_unchanged':True,'native_game_acceptance':False}
 p.save(build/'trial3-verification.json',receipt);print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':main()
