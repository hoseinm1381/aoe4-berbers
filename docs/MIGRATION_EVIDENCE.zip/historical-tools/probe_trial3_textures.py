import inspect,json
import prepare_trial as p
from garrison_shared import rrtex_encoder, rrtex_decoder
for mod in (rrtex_encoder,rrtex_decoder):
 print(mod.__name__,[(k,str(inspect.signature(v))) for k,v in vars(mod).items() if inspect.isfunction(v)])
game=p.stock_game.current()
archive=p.ROOT/'authoring-library/Mods/berbers/dist/berbers.sga'
member='ui/images/garrison/berbers/presentation/flag_list_t3.rrtex'
f=p.ROOT/'output/trial3-audit/flag_list_t3.rrtex'
f.write_bytes(game.archiver.read(archive,member))
doc=rrtex_decoder.load(f)
print('DOC',type(doc),dir(doc))
nodes={n.tag:n for n in doc.walk()}
rrtex_decoder._validate_stream_table(nodes[b'TMAN'].payload,nodes[b'TDAT'].payload)
fmt,mips=rrtex_decoder._decode_mips(nodes[b'TDAT'].payload)
print('FORMAT',fmt,'MIPS',[(vars(m).keys(),str(m)[:100]) for m in mips])
f.with_suffix('.dds').write_bytes(rrtex_decoder._dds(mips,98))
from PIL import Image
im=Image.open(f.with_suffix('.dds'));print('IMAGE',im.size,im.mode);im.save(f.with_suffix('.png'))
