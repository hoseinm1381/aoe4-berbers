"""Regression for the actual native 'missing metadata' import failure."""
import json
from pathlib import Path
import prepare_trial as p


def require_metadata(members):
    for name in ('mod.bin','mod.rrtex'):
        assert name in members and members[name]['toc']=='info',('Missing native info member',name)
        assert members[name].get('bytes',1)>0,('Empty native info member',name)


def main():
    old=json.loads((p.WORK/'finalized/report.json').read_text())
    try:
        require_metadata(old['members'])
    except AssertionError as exc:
        old_failure=str(exc)
    else:
        raise AssertionError('Regression failed to reject the broken trial.1 archive')
    recipe=json.loads((p.ROOT/'build-recipe.json').read_text())
    indexed={r['member']:r for r in recipe['members']}
    require_metadata(indexed)
    carrier=p.WORK/'core-members'
    assert (carrier/'mod.bin').read_bytes().startswith(b'Relic Chunky')
    game=p.stock_game.current()
    native=p.ROOT/'authoring-library/Mods/berbers/dist/berbers.sga'
    rows={r['path']:r for r in game.archiver.members(native)}
    for name in ('mod.bin','mod.rrtex'):
        assert rows[name]['toc']=='info'
        assert game.archiver.read(native,name)==(carrier/name).read_bytes()
        assert p.sha((carrier/name).read_bytes())==indexed[name]['sha256']
    result={'old_trial_rejected':True,'old_failure':old_failure,'new_recipe_passed':True,
            'own_cooked_carrier_bytes_verified':True,'native_metadata_members':['mod.bin','mod.rrtex'],
            'game_acceptance':False}
    p.save(p.ROOT/'output/dropdown-investigation/metadata-regression.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
