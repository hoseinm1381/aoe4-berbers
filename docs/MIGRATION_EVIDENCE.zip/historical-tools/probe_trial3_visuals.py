import json
import prepare_trial as p
base=p.ROOT/'output/dropdown-fix/build/readback'
report={}
for stem in ('building_town_center_capital_mal','unit_villager_1_mal','unit_scout_1_mal'):
 f=next((base/'attrib/ebps').rglob(stem+'.rgd'))
 d=p.rgd.read(f.read_bytes())
 report[stem]=[(q,n.kind,n.value) for q,n in p.rgd.flatten(d.nodes) if q.startswith('default/') and not isinstance(n.value,list) and any(s in q for s in ('attach','animator','state','model','spawn','tier_ext'))]
p.save(p.ROOT/'output/trial3-audit/visual-starting-fields.json',report)
for k,v in report.items():print(k,json.dumps([r for r in v if '/tier_ext/' in r[0]][:85],indent=2))
