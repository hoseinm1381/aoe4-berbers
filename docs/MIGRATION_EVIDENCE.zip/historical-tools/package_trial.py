"""Package only a completely read-back-verified pilot using Garrison's writer."""
import hashlib
import json
import zipfile
import argparse
from pathlib import Path
import prepare_trial as p
from garrison_shared import mod_bundle
from check_native_metadata import require_metadata


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--build',type=Path,default=p.WORK/'finalized')
    parser.add_argument('--delivery',type=Path,default=p.WORK/'delivery-final')
    parser.add_argument('--version',default='0.1.0-trial.1')
    parser.add_argument('--trial3',action='store_true',help='Use reviewed trial.3 presentation and verification receipts')
    args=parser.parse_args()
    build=args.build.resolve()
    report=json.loads((build/'report.json').read_text())
    require_metadata(report['members'])
    archive=Path(report['archive'])
    assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()==report['sha256']
    audit=json.loads((p.WORK/'audit/semantic-audit.json').read_text())
    assert not audit['unresolved_stock_references']
    details={'id':'berbers','name':'Berbers (Trial)','version':args.version,
             'summary':'Experimental independent Berber civilization for the Garrison dropdown.',
             'description':'Local owner-test pilot. Select Berbers (Trial) with Standard and Tuning Pack=None. Native acceptance pending.',
             'author':'hosein81 and marcokistan','updated':'2026-10-30','min_garrison':'0.1.9',
             'content_types':['civilization'],
             'changelog':'Restores missing native info/mod.bin and info/mod.rrtex from the owned cook. All 2,846 previous member bytes preserved. Human Dark Age trial; Codex presentation provisional.'}
    if args.trial3:
        checks=json.loads((p.ROOT/'output/trial3-audit/checks.json').read_text())
        verification=json.loads((build/'trial3-verification.json').read_text())
        assert verification['all_members_read_back'] and checks['private_identity_records']==128
        assert checks.get('cross_civ_influence_regression') is True,'Missing cross-civilization influence isolation check'
        notes=(p.ROOT/'START-HERE.md').read_text(encoding='utf8')
        assert all(name in notes for name in ('hossein81','marcokistan','Karyu','lammet','ForsakenCryz')),'Missing original author/media credits'
        details.update(name='Berbers',cover='cover.png',summary='The Berber Dynasties: tribal alliances, desert warriors and trade.',
          description='Trial 3. Independent civilization for Standard with Tuning Pack=None. Updated Berber blueprint identities, Tent/landmark checks, Codex, flags and loading artwork. In-game testing remains pending.',
          changelog='Trial 3: private identities for 128 legacy stock-named definitions; corrected BP_GetName comparisons; actual Berber Codex and bonuses; new original vector flags and loading banner. Original composed models, voices and music preserved.')
    delivery=args.delivery.resolve()
    delivery.mkdir(parents=True,exist_ok=True)
    target=delivery/('Berbers-Garrison-'+args.version+'.zip')
    result=mod_bundle.write_package(delivery/'package',target,bundle_key='berbers',
          details=details,archives=[('berbers','civilization',archive)],
          start_here=(p.ROOT/'START-HERE.md').read_text(),
          cover=p.ROOT/'source/presentation/trial3/cover.png' if args.trial3 else None)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        manifest_name=next(n for n in z.namelist() if n.endswith('garrison.json'))
        manifest=json.loads(z.read(manifest_name))
        member=manifest['members'][0]
        assert member['role']=='civilization' and member['mod_key']=='berbers'
        prefix=manifest_name[:-len('garrison.json')]
        with z.open(prefix+member['path']) as stream:
            assert hashlib.file_digest(stream,'sha256').hexdigest()==report['sha256']
        if args.trial3:
            assert z.read(prefix+'cover.png')==(p.ROOT/'source/presentation/trial3/cover.png').read_bytes()
            player_notes=[z.read(n).decode('utf8') for n in z.namelist() if n.lower().endswith(('.txt','.md'))]
            assert any(all(name in note for name in ('hossein81','marcokistan','Karyu','lammet','ForsakenCryz')) for note in player_notes),'Original credits missing from final player notes'
    receipt={'schema':'berbers.pilot-delivery/v1','zip':str(target),'zip_bytes':target.stat().st_size,
             'zip_sha256':hashlib.file_digest(target.open('rb'),'sha256').hexdigest(),
             'archive_bytes':archive.stat().st_size,'archive_sha256':report['sha256'],
             'manifest':manifest,'zip_crc_checked':True,'packaged_sga_hash_checked':True,
             'under_600000000_bytes':target.stat().st_size<600000000,
             'original_release_zip_bytes':685072275,'runtime_acceptance':False,
             'editable_standalone_handoff_complete':False}
    p.save(delivery/'delivery-receipt.json',receipt)
    (delivery/'SHA256SUMS.txt').write_text(receipt['zip_sha256']+'  '+target.name+'\n',encoding='ascii')
    print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'},indent=2),flush=True)


if __name__=='__main__':
    main()
