"""Save the actual native failure and corrected package receipt for review."""
import json
from pathlib import Path
import prepare_trial as p


def main():
    audit=p.ROOT/'output/dropdown-investigation'
    warnings=Path.home()/'Documents/My Games/Age of Empires IV/warnings.log'
    saved=audit/'game-warning-evidence.json'
    if saved.is_file():
        evidence=json.loads(saved.read_text())['lines']
    else:
        lines=warnings.read_text(encoding='utf-8-sig',errors='replace').splitlines()
        evidence=[{'line':i+1,'text':line} for i,line in enumerate(lines)
                  if ('berbers.sga' in line or 'persians_independent.sga' in line)]
    assert any('missing metadata' in row['text'] for row in evidence)
    p.save(audit/'game-warning-evidence.json',{'source':str(warnings),'lines':evidence})
    events_path=Path.home()/'AppData/Local/Garrison/events/31552.jsonl'
    kinds={'provider_ready','civilization_service_registered','civilization_resources_retained',
           'civilization_owner_retained','civilization_race_admitted'}
    events=[json.loads(s) for s in events_path.read_text().splitlines() if s]
    selected=[r for r in events if r.get('kind') in kinds]
    p.save(audit/'admission-evidence.json',{'source':str(events_path),'events':selected})
    delivery=p.ROOT/'output/dropdown-fix/delivery'
    receipt=json.loads((delivery/'delivery-receipt.json').read_text())
    build=json.loads((p.ROOT/'output/dropdown-fix/build/report.json').read_text())
    meta=build['metadata_fix']
    failure=next(r for r in evidence if 'missing metadata' in r['text'])
    report=f'''# Berber dropdown failure: confirmed native metadata omission

Date: 2026-10-30. Trial.1 failed the owner's in-game dropdown test.
The working comparison is the installed official-catalog Persians 0.1.0, SGA
SHA-256 `1e999c7220ab7a3b7868f3d48cfa66e3bce36abd068410609f1ff1b6745fc384`.
Its installed group identifies source
`https://raw.githubusercontent.com/AOE-Garrison/garrison-mod-catalog/main/catalog-v2.json`.

## Confirmed cause

AoE4 `warnings.log`, line {failure['line']}, at 02:17:11:

> Error loading mod pack '.../berbers/berbers.sga': missing metadata.

The preceding ARC line identifies the exact trial owner and 769,805,910-byte
archive; it is not a different/older Berber mod. Garrison's installed digest
also matches the delivered trial.1 archive. The game scanned it but rejected it
before creating the native mod owner/race.

| Native/package surface | Working Persia | Berber trial.1 |
| --- | --- | --- |
| `info` TOC | Present | Absent |
| `mod.bin` in `info` (native compiled mod metadata) | Present | **Missing** |
| `mod.rrtex` in `info` (native mod image) | Present | Missing |
| Additive root Boolean false / own header ID | Present/correct | Present/correct |
| Hashed civilization declaration and one flat RaceBP | Present | Present |
| Visible multiplayer race / base-game eligibility | Enabled | Same relevant settings |
| Included in Garrison native provider request | Yes | Yes |
| Native resource mount, owner retention and race admission | Recorded | **No event** |

`garrison.json` and `garrison/civilizations.json` serve Garrison. They do not
replace AoE4's compiled `info:mod.bin`. The omission is in our assembly recipe:
it copied data/locales/attributes but never carried the author's own cooked info
members into the final archive. The generic structural validator allowed that
incomplete archive, and the earlier ZIP/CRC checks only proved its bytes readable.
This was an assembly and validation gap, not a missing civilization toggle.
The log directly establishes missing native metadata as the rejection; it does
not independently establish that the missing image alone would prevent loading.

Persia additionally has a finished flag suite, Overview bonuses, Codex layout and
client civilization-card metadata. Berber presentation remains provisional.
Those differences do not explain this earlier native metadata rejection.

## Local correction: 0.1.0-trial.2

New test ZIP: `{receipt['zip']}`

- ZIP bytes: **{receipt['zip_bytes']:,}**.
- ZIP SHA-256: `{receipt['zip_sha256']}`.
- Native SGA SHA-256: `{receipt['archive_sha256']}`.
- Restored only `mod.bin` and `mod.rrtex` under the **info TOC**.
- Both inputs are byte-verified against our existing native cooked Berber core
  carrier, with its own `5fe8767c-ca3a-4e64-9e20-c9527cf014ec` project identity.
  No Persian metadata/UUID or original Berber identity was borrowed.
- All **{meta['all_previous_members_identical']:,} previous member bytes and TOCs
  remain identical**, including gameplay, art, localization and scripts.
- All **{meta['all_members_read_back']:,} final members** were read back and matched
  against path/TOC/SHA-256; stored CRC32/SHA1 verification passed.
- The new regression rejects the actual failed trial.1 inventory and accepts
  the complete recipe/cooked metadata. Packaging now enforces this check too.
- ZIP CRC and packaged SGA SHA-256 checks passed.

The old trial remains preserved for evidence. Nothing was installed, enabled,
disabled, launched or pushed by this correction. Native acceptance is **pending**;
restoring the proven missing metadata does not establish the later gameplay gates.

Close AoE4, import/update to **0.1.0-trial.2** in Garrison, enable it, and launch
fresh. Use Standard, Tuning Pack=None, Dark Age and a human Berber player. For this
test disable other custom civilization packs, including Persia, before launch.
The package version changes; its unchanged SCAR diagnostic marker still reports
the original trial.1 mechanics version because this fix adds metadata only.

## Reproduction and receipts

`tools/prepare_runtime.py` includes the own-carrier info inputs in the recipe.
`tools/check_native_metadata.py` is the failing-before/passing-after regression.
`tools/build_metadata_fix.py` adds exactly the missing info members with the native
archiver, preserves the previous package and verifies every final member.
`tools/package_trial.py` takes explicit build/delivery/version arguments and
rejects archives missing native metadata.

Evidence: `output/dropdown-investigation/package-comparison.json`,
`game-warning-evidence.json`, `admission-evidence.json`, `metadata-regression.json`,
and `output/dropdown-fix/build/report.json`. The delivery directory contains
`delivery-receipt.json` and `SHA256SUMS.txt`.
'''
    target=p.ROOT/'docs/DROPDOWN_FAILURE_20261030.md'
    target.write_text(report,encoding='utf8')
    print(target)


if __name__=='__main__':
    main()
