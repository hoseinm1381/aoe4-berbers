import json
import prepare_trial as p
base=p.ROOT/'output/dropdown-fix/build/readback'
for fam in ('army','codex'):
 f=next((base/'attrib'/fam).rglob('*.rgd'))
 doc=p.rgd.read(f.read_bytes())
 paths=['default/army_bag'] if fam=='army' else ['default/codex_bag/tech_tree','default/codex_bag/root_item']
 for path in paths:
  n=p.rgd.find(doc.nodes,path)
  def shape(n,depth):return [n.key,n.hash,n.kind,([shape(c,depth-1) for c in n.value] if depth else '<list>') if isinstance(n.value,list) else n.value]
  p.save(p.ROOT/'output/trial3-audit'/('shape-'+path.split('/')[-1]+'.json'),shape(n,5 if fam=='army' else 3))
