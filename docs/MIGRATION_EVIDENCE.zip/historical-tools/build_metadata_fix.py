"""Restore only our cooked native info members, then verify the entire archive."""
import copy
import hashlib
import json
import shutil
from pathlib import Path
import prepare_trial as p
from check_native_metadata import require_metadata


def main():
    prior=json.loads((p.WORK/'finalized/report.json').read_text())
    work=p.ROOT/'output/dropdown-fix/build'
    assert not work.exists(),work
    work.mkdir(parents=True)
    additions={name:(p.WORK/'core-members'/name).read_bytes() for name in ('mod.bin','mod.rrtex')}
    assert all(name not in prior['members'] for name in additions)
    game=p.stock_game.current()
    generated=game.archiver.set_members(Path(prior['archive']),additions,work/'graft',toc='info')
    final=work/'berbers.sga'
    shutil.copyfile(generated,final)
    listing=game.archiver.run(['list',str(final),'--verify'])
    p.save(work/'list.json',listing)
    assert listing['archive']['name']==p.OWNER and listing['archive']['verification']['verified']
    expected=copy.deepcopy(prior['members'])
    for name,raw in additions.items():
        expected[name]={'toc':'info','sha256':p.sha(raw),'bytes':len(raw)}
    require_metadata(expected)
    actual={r['path']:r for r in listing['members']}
    assert set(actual)==set(expected)
    game.archiver.run(['extract',str(final),str(work/'readback'),'--filter',''])
    for name,row in expected.items():
        assert actual[name]['toc']==row['toc'],name
        assert p.sha((work/'readback'/name).read_bytes())==row['sha256'],name
    report=copy.deepcopy(prior)
    report.update(archive=str(final),sha256=hashlib.file_digest(final.open('rb'),'sha256').hexdigest(),members=expected)
    report['metadata_fix']={'source_archive_sha256':prior['sha256'],'added_info_members':sorted(additions),
           'all_previous_members_identical':len(prior['members']),'all_members_read_back':len(expected),
           'native_crc_sha1_verified':True,'runtime_acceptance':False}
    p.save(work/'report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k in ('archive','sha256','metadata_fix')},indent=2),flush=True)


if __name__=='__main__':
    main()
