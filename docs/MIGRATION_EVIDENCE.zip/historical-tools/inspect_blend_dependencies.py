"""Background Blender only: inspect external images without saving any scene."""
import bpy
import json
import sys
from pathlib import Path

root=Path(sys.argv[sys.argv.index('--')+1])
plan=json.loads((root/'output/master-plan.json').read_text())
blends=sorted({r['original'] for r in plan['files'] if r['path'].endswith('.blend')})
result=[]
for i,path in enumerate(blends):
    bpy.ops.wm.open_mainfile(filepath=path, load_ui=False, use_scripts=False)
    row={'path':path,'images':[], 'libraries':[
        bpy.path.abspath(lib.filepath) for lib in bpy.data.libraries]}
    for im in bpy.data.images:
        row['images'].append({'name':im.name,'path':bpy.path.abspath(im.filepath, library=im.library),
                              'packed':bool(im.packed_file),'source':im.source})
    result.append(row)
    (root/'output/blend-dependencies.json').write_text(json.dumps(result,indent=2))
    print('MASTER_INSPECTION',i+1,len(blends),flush=True)
