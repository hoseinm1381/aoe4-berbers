"""Original editable vector heraldry and Maghrebi gate illustration for trial.3.

No historical-flag claim. SVG shapes and PNGs are generated from the same recipe.
"""
from pathlib import Path
import html
import json
import math
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'source/presentation/trial3'
GOLD='#d8b668'; LIGHT='#f1dc9f'; GREEN='#153f37'; RED='#8b3036'


class Vector:
    def __init__(self,w,h):
        self.w,self.h=w,h
        self.scale=2
        self.image=Image.new('RGBA',(w*2,h*2),(0,0,0,0))
        self.draw=ImageDraw.Draw(self.image)
        self.svg=[]
    def poly(self,points,fill,stroke=None,width=1):
        self.draw.polygon([(x*2,y*2) for x,y in points],fill=fill)
        if stroke:
            self.draw.line([(x*2,y*2) for x,y in points+[points[0]]],fill=stroke,width=max(1,int(width*2)),joint='curve')
        self.svg.append('<polygon points="'+ ' '.join(f'{x:.2f},{y:.2f}' for x,y in points)+'" fill="'+fill+'"'+(f' stroke="{stroke}" stroke-width="{width}"' if stroke else '')+'/>')
    def line(self,points,color,width):
        self.draw.line([(x*2,y*2) for x,y in points],fill=color,width=max(1,int(width*2)),joint='curve')
        self.svg.append('<polyline points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y in points)+f'" fill="none" stroke="{color}" stroke-width="{width}"/>')
    def rect(self,box,color,stroke=None,width=1):
        x,y,x2,y2=box
        self.poly([(x,y),(x2,y),(x2,y2),(x,y2)],color,stroke,width)
    def circle(self,x,y,r,fill,stroke=None,width=1):
        self.draw.ellipse(((x-r)*2,(y-r)*2,(x+r)*2,(y+r)*2),fill=fill,outline=stroke,width=max(1,int(width*2)))
        self.svg.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{width}"' if stroke else '')+'/>')
    def text(self,x,y,text,size,color):
        font=ImageFont.truetype('C:/Windows/Fonts/georgiab.ttf',int(size*2))
        self.draw.text((int(x*2),int(y*2)),text,font=font,fill=color,anchor='mt')
        self.svg.append(f'<text x="{x}" y="{y+size}" text-anchor="middle" font-family="Georgia,serif" font-weight="bold" font-size="{size}" fill="{color}">{html.escape(text)}</text>')
    def save(self,name,fade=False):
        image=self.image.resize((self.w,self.h),Image.Resampling.LANCZOS)
        if fade:
            alpha=Image.new('L',(self.w,self.h))
            draw=ImageDraw.Draw(alpha)
            for x in range(self.w):
                value=round(225*max(0,min(1,(x/self.w-.28)/.67))**1.5)
                draw.line((x,0,x,self.h),fill=value)
            image.putalpha(alpha)
        image.save(OUT/(name+'.png'),optimize=True)
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">'+''.join(self.svg)+'</svg>'
        (OUT/(name+'.svg')).write_text(svg,encoding='utf8')
        return image


def emblem(v,cx,cy,r):
    points=[]
    for i in range(16):
        a=-math.pi/2+i*math.pi/8
        radius=r if i%2==0 else r*.61
        points.append((cx+math.cos(a)*radius,cy+math.sin(a)*radius))
    v.poly(points,GOLD,LIGHT,max(1,r*.017))
    v.circle(cx,cy,r*.49,GREEN,LIGHT,max(1,r*.018))
    # A compact fortified horseshoe arch; readable even in the list flag.
    w=r*.25
    v.rect((cx-w,cy-r*.14,cx+w,cy+r*.29),GOLD)
    v.circle(cx,cy-r*.14,w,GOLD)
    v.rect((cx-w*.53,cy-r*.12,cx+w*.53,cy+r*.29),GREEN)
    v.circle(cx,cy-r*.12,w*.53,GREEN)
    v.rect((cx-r*.29,cy+r*.29,cx+r*.29,cy+r*.34),RED)


def flag(w,h,name):
    v=Vector(w,h)
    v.rect((0,0,w,h),GREEN)
    v.rect((0,h*.84,w,h),RED)
    v.line([(0,h*.84),(w,h*.84)],GOLD,max(1,h*.025))
    v.rect((w*.025,h*.05,w*.975,h*.95),'#17483e',GOLD,max(.7,h*.018))
    v.rect((w*.035,h*.80,w*.965,h*.93),RED)
    emblem(v,w*.5,h*.45,h*.36)
    v.save(name)


def landscape(w,h,name,title=False,fade=False):
    v=Vector(w,h)
    # Quiet dark left side for native tooltip/name overlays.
    for y in range(0,h,4):
        t=y/max(1,h-1)
        rgb=(int(12+12*t),int(31+23*t),int(33+14*t))
        v.rect((0,y,w,min(h,y+4)),'#%02x%02x%02x'%rgb)
    for i in range(9):
        x=w*(.36+i*.09)
        v.line([(x,0),(x-h*.24,h)],'#284c43',max(1,w*.001))
    v.circle(w*.79,h*.2,h*.082,'#c5aa71')
    v.circle(w*.81,h*.18,h*.081,'#173b35')
    v.poly([(0,h*.69),(w*.27,h*.56),(w*.47,h*.65),(w*.62,h*.37),(w*.77,h*.53),(w*.9,h*.38),(w,h*.54),(w,h),(0,h)],'#31564b')
    v.poly([(0,h*.81),(w*.3,h*.70),(w*.52,h*.78),(w*.78,h*.59),(w,h*.67),(w,h),(0,h)],'#8f7350')
    v.poly([(0,h*.92),(w*.42,h*.8),(w*.73,h*.87),(w,h*.73),(w,h),(0,h)],'#b38e55')
    # Stylized adobe gate and crenellated towers, with restrained gilded edges.
    left,right=w*.62,w*.88
    top,base=h*.48,h*.88
    v.rect((left,top,right,base),'#a37c48',GOLD,h*.002)
    for xx in (left-w*.035,right-w*.045):
        v.poly([(xx,top+h*.02),(xx+w*.08,top),(xx+w*.07,base),(xx-w*.01,base)],'#c59d5d',GOLD,h*.002)
        for q in range(4):
            bx=xx+q*w*.02
            v.rect((bx,top-h*.025,bx+w*.014,top+h*.025),'#c59d5d')
        v.rect((xx+w*.025,top+h*.10,xx+w*.045,top+h*.18),'#3e4935')
        v.line([(xx+w*.01,base-h*.08),(xx+w*.06,base-h*.08)],GOLD,h*.006)
    cx=w*.75
    v.rect((cx-w*.045,top+h*.15,cx+w*.045,base),'#25463a')
    v.circle(cx,top+h*.16,w*.045,'#25463a')
    v.rect((cx-w*.027,top+h*.17,cx+w*.027,base),'#0e2729')
    v.circle(cx,top+h*.17,w*.027,'#0e2729')
    v.line([(cx,top+h*.14),(cx,base)],'#9b7b4d',h*.003)
    for i in range(5):
        x=w*(.59+i*.08)
        v.line([(x,h*.87),(x-w*.01,h*.69)],'#203d33',h*.009)
        for dx in (-.04,-.025,.025,.04):
            v.line([(x-w*.01,h*.69),(x+w*dx,h*.66)],'#203d33',h*.006)
    emblem(v,w*.26,h*.43,min(w,h)*.20)
    if title:
        v.text(w*.26,h*.68,'BERBERS',h*.077,LIGHT)
        v.text(w*.26,h*.79,'THE BERBER DYNASTIES',h*.022,GOLD)
    v.line([(w*.025,h*.035),(w*.975,h*.035)],GOLD,max(1,h*.002))
    v.line([(w*.025,h*.965),(w*.975,h*.965)],GOLD,max(1,h*.002))
    return v.save(name,fade=fade)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    specs={'flag_list_t3':(104,56),'flag_list_small_t3':(52,28),
           'flag_secondary_t3':(440,248),'flag_secondary_small_t3':(220,124),
           'flag_fade_t3':(344,104),'flag_mastery_t3':(1112,588)}
    for name,(w,h) in specs.items():
        flag(w,h,name)
    for name,w,h,title,fade in [('flag_loading_t3',1920,1080,False,False),
              ('flag_background_t3',1920,1080,False,False),('flag_tile_t3',736,800,False,False),
              ('flag_pattern_t3',1120,352,False,True),('cover',1920,1080,True,False)]:
        landscape(w,h,name,title=title,fade=fade)
    (OUT/'AUTHORED.md').write_text('# Berber trial.3 banner sources\n\nOriginal vector artwork: Maghrebi gate, dunes and geometric star on green/gold/crimson.\nThis is a test-civilization graphic, not an asserted historical flag.\nEdit the SVGs or tools/make_trial3_banner.py. PNGs are UI-cook inputs.\nThe loading card alpha fade is generated in the recipe after rasterization.\n',encoding='utf8')
    print(OUT,flush=True)


if __name__=='__main__':
    main()
