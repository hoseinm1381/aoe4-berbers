"""Inspect collision/visual/menu data without changing original workspaces."""
import collections
import json
import struct
import uuid
from pathlib import Path
import prepare_trial as p


def main():
    audit=p.ROOT/'output/trial3-audit'
    old=json.loads((p.ROOT/'output/dropdown-fix/build/report.json').read_text())
    game=p.stock_game.current()
    game.blueprint('racebps/malian')
    stock_rows=game.archiver.members(game._connection.attributes)
    stock_index=collections.defaultdict(list)
    for row in stock_rows:
        m=row['path']
        if row.get('toc')=='attrib' and m.endswith('.rgd') and m.count('/')>=2:
            stock_index[p.key(m)].append(m)
    collisions=[]
    graphs={}
    for member,row in old['members'].items():
        if row['toc']!='attrib' or member.count('/')<2:
            continue
        raw=(p.ROOT/'output/dropdown-fix/build/readback'/member).read_bytes()
        doc=p.rgd.read(raw)
        ident=p.key(member)
        current=p.rgd.find(doc.nodes,'default/pbgid')
        if ident in stock_index:
            other=stock_index[ident][0]
            stock_raw=game.blueprint(other[len('attrib/'):-4])
            stock_doc=p.rgd.read(stock_raw)
            native=p.rgd.find(stock_doc.nodes,'default/pbgid')
            collisions.append({'member':member,'stock_member':other,'same_native_id':current.value==native.value,
                               'id':current.value,'stock_id':native.value})
        if ident[0] in ('ebps','sbps'):
            menus=[(path,n.value,m.value) for path,n,m in p.refs(doc.nodes)
                   if path.startswith('default/') and any(x in path for x in
                     ('/spawner_ext/','/upgrade_ext/','/squad_engineer_ext/'))]
            if menus:
                graphs[member]=menus
    p.save(audit/'stock-identity-collisions.json',collisions)
    p.save(audit/'production-menus.json',graphs)
    print('COLLISIONS',len(collisions),'same native ID',sum(r['same_native_id'] for r in collisions),flush=True)
    print('STARTER SAMPLE',json.dumps([r for r in collisions if 'villager_1' in r['member'] or 'town_center_capital' in r['member']],indent=2))
    codex=next((p.ROOT/'output/dropdown-fix/build/readback').rglob('berbers_codex.rgd'))
    doc=p.rgd.read(codex.read_bytes())
    leaves=[(path,n.kind,n.value) for path,n in p.rgd.flatten(doc.nodes) if not isinstance(n.value,list)]
    p.save(audit/'codex-layout.json',leaves)
    print('MENU SAMPLE',json.dumps({k:v for k,v in graphs.items() if 'building_unit_infantry' in k},indent=2)[:7500])
    needles=[p.OLD.encode(),str(uuid.UUID(p.OLD)).encode(),p.OLD.encode('utf-16-le'),uuid.UUID(p.OLD).bytes,uuid.UUID(p.OLD).bytes_le]
    embedded=[]
    for member,row in old['members'].items():
        if member.startswith('art/') and row['bytes']>30:
            raw=(p.ROOT/'output/dropdown-fix/build/readback'/member).read_bytes()
            found=[i for i,n in enumerate(needles) if n in raw]
            if found:
                embedded.append({'member':member,'patterns':found})
    p.save(audit/'embedded-old-art-owner.json',embedded)
    print('EMBEDDED OLD ART OWNERS',len(embedded),flush=True)


if __name__=='__main__':
    main()
