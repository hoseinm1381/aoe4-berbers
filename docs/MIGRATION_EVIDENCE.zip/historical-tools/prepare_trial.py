"""Prepare a guarded native-data pilot; never writes into the original mod.

Uses the installed Garrison RGD reader/writer and the compiled civilization
assembler. The generated Codex is a rebased stock Malian presentation for this
first gameplay trial, not a claim of a complete custom technology-tree layout.
"""
from pathlib import Path
import collections
import copy
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT/'output/pilot'
EXT = Path.home()/'AppData/Roaming/Blender Foundation/Blender/5.2/extensions/raw_githubusercontent_com/garrison'
ARCH = EXT/'bin/sga-archiver.exe'
BASE = Path('F:/aoe_4_temp/Berber_future_kingdom_ai_20261014/output/berber_update_1_0_4/Berber_future_kingdom.sga')
OLD = '1d3145e8f1b2427f8bb0067851fcf0f1'
PROFILE = json.loads((ROOT/'authoring-profile.json').read_text())
OWNER = PROFILE['owner'].replace('-', '')
RACE = OWNER+':berbers'
sys.path.insert(0, str(EXT))
from garrison_shared import rgd, stock_game


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, doc):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2)+'\n', encoding='utf8')


def encode(doc):
    keys = {h:k for h,k in doc.keys}
    for _, node in rgd.flatten(doc.nodes):
        if node.key is not None:
            keys[node.hash] = node.key
    doc.keys = list(keys.items())
    raw = rgd.write(doc)
    check = rgd.read(raw)
    def semantic(nodes):
        return [(n.key,n.hash,n.kind,semantic(n.value) if isinstance(n.value,list) else n.value) for n in nodes]
    assert semantic(check.nodes) == semantic(doc.nodes), 'RGD roundtrip changed values'
    return raw


def family(member):
    parts = member.split('/')
    return '/'.join(parts[1:3]) if parts[1] in ('attachments','ai') else parts[1]


def key(member):
    return family(member), Path(member).stem


def child(node, name):
    return next((n for n in node.value if n.key==name), None)


def refs(nodes):
    for path, node in rgd.flatten(nodes):
        if not isinstance(node.value, list):
            continue
        name, mapping = child(node, '$PBGNAME'), child(node, '$PBGMAP')
        if name is not None and mapping is not None and name.value:
            yield path, name, mapping


def replace_child(parent, name, source):
    old = child(parent, name)
    assert old is not None, name
    position = parent.value.index(old)
    node = copy.deepcopy(source)
    node.key = old.key
    node.hash = old.hash
    parent.value[position] = node


def rehome(raw, owned, membership=True):
    doc = rgd.read(raw)
    changes = []
    for path, name, mapping in list(refs(doc.nodes)):
        old = name.value
        fam = mapping.value.replace('\\','/')
        if '/parent_pbg' in '/'+path:
            name.value = ''
            mapping.value = ''
        elif membership and ('/race_type_list/' in path or '/squad_race_type_list/' in path):
            name.value = RACE
            mapping.value = 'racebps'
        elif old.startswith(OLD+':'):
            name.value = OWNER+old[len(OLD):]
        elif ':' not in old and (fam,old) in owned:
            name.value = OWNER+':'+old
        if old != name.value:
            changes.append([path,old,name.value])
    for path, node in rgd.flatten(doc.nodes):
        if node.kind == 'LocString' and isinstance(node.value,str):
            node.value = node.value.replace('$'+OLD+':','$'+OWNER+':')
        if node.kind=='CString' and isinstance(node.value,str) and 'set_civ_dynamic_root\\mal' in node.value:
            assert node.value == 'building_action_apply\\buildings\\town_center_action_apply\\set_civ_dynamic_root\\mal'
            changes.append([path,node.value,''])
            node.value = ''
    return doc,changes


def ucs_entries(raw):
    text = raw.decode('utf-16')
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        number, text = line.split('\t',1)
        assert int(number) not in result
        result[int(number)] = text
    return result


def prepare():
    assert hashlib.file_digest(BASE.open('rb'),'sha256').hexdigest() == '55629909581fd0035a141f212e38274d3e1f7f185fecffed635b821e2b7204a6'
    listing = json.loads((WORK/'audit/baseline-list.json').read_text())
    mounts = {row['path']:row['toc'] for row in listing['members']}
    source = {}
    aliases = []
    for file in sorted((WORK/'baseline-attributes/attrib').rglob('*.rgd')):
        member = file.relative_to(WORK/'baseline-attributes').as_posix()
        if mounts[member] != 'attrib':
            # Native AI data records are not attribute-TOC definitions. Preserve
            # the originals as inputs; human pilot does not replace global AI.
            continue
        if member.count('/') == 1 or member.startswith('attrib/army/'):
            continue
        ident = key(member)
        raw = file.read_bytes()
        if ident in source:
            other_member, other_raw = source[ident]
            assert [(p,n.kind,n.value) for p,n in rgd.flatten(rgd.read(raw).nodes) if not isinstance(n.value,list)] == [(p,n.kind,n.value) for p,n in rgd.flatten(rgd.read(other_raw).nodes) if not isinstance(n.value,list)], ident
            aliases.append([other_member,member,'identical decoded leaves and native PBG ID'])
            # Canonical path is the shortest; both identities are demonstrably equal.
            if len(member)<len(other_member):
                source[ident] = (member,raw)
        else:
            source[ident] = (member,raw)
    core = {}
    for file in (WORK/'core-members/attrib').rglob('*.rgd'):
        member = file.relative_to(WORK/'core-members').as_posix()
        if member.count('/')>1:
            core[key(member)] = (member,file.read_bytes())
    owned = set(source)|set(core)
    owned.add(('racebps','berbers'))
    owned.add(('army','normal_malian'))
    converted = {}
    edits = {}
    for ident,(member,raw) in source.items():
        doc,changes = rehome(raw,owned)
        converted[member] = doc
        edits[member] = changes

    # Generated core is already owned. It is not subject to sparse-source rebasing.
    for ident,(member,raw) in core.items():
        converted[member] = rgd.read(raw)
    # The assembler requires the complete owned attribute inventory, including
    # the native root. This pilot is additive and must not override stock data.
    root_member='attrib/berbers.rgd'
    root=rgd.read((WORK/'core-members'/root_member).read_bytes())
    override=[n for path,n in rgd.flatten(root.nodes) if n.key=='override_instances']
    assert len(override)==1 and override[0].kind=='Boolean'
    assert override[0].value is True or override[0].value is False
    override[0].value=False
    converted[root_member]=root
    core_members = {fam:(member,converted[member]) for (fam,name),(member,_) in core.items()}
    army_member, army = core_members['army']
    old_army = (WORK/'baseline-attributes/attrib/army/standard_mode/normal_malian.rgd').read_bytes()
    migrated_army,_ = rehome(old_army,owned)
    native_start = rgd.find(migrated_army.nodes,'default/army_bag')
    for variant in rgd.tables(army.nodes):
        bag = rgd.find(army.nodes,variant+'/army_bag')
        for name in ('starting_units','starting_units_spawner','starting_buildings','resource_starting_amount'):
            replace_child(bag,name,child(native_start,name))
        start = child(bag,'start_actions_statetree')
        assert start is not None
        start.value = ''
    # Retain the native stock roster/archetype structure, with explicit owned links.
    game = stock_game.current()
    stock_race = rgd.read(game.blueprint('racebps/malian'))
    old_race = rgd.find(stock_race.nodes,'default/race_bag')
    race_member,race = core_members['racebps']
    for variant in rgd.tables(race.nodes):
        bag = rgd.find(race.nodes,variant+'/race_bag')
        for name in ('blueprint_archetypes','blueprint_archetypes_groups','resource_gatherer_blueprints',
                     'resource_gatherer_squad_blueprints','naval_gatherer_blueprint'):
            original = child(old_race,name)
            if original is not None and child(bag,name) is not None:
                replace_child(bag,name,original)
        for name,path in [('asset_directory_ebps','attrib\\ebps\\races\\malian'),
                          ('asset_directory_sbps','attrib\\sbps\\races\\malian')]:
            if child(bag,name):
                child(bag,name).value=path
    race2,changes = rehome(encode(race),owned,membership=False)
    converted[race_member] = race2
    # A conservative, native stock layout is retained for the trial. Custom
    # additions need a later presentation pass; this does not alter production.
    codex_member,codex = core_members['codex']
    stock_codex = rgd.read(game.blueprint('codex/malian'))
    for variant in rgd.tables(codex.nodes):
        target = rgd.find(codex.nodes,variant+'/codex_bag')
        original = rgd.find(stock_codex.nodes,'default/codex_bag')
        target.value = copy.deepcopy(original.value)
    converted[codex_member],changes = rehome(encode(codex),owned,membership=False)

    # No starter-army reference may resolve back to the stock replacement.
    for doc in converted.values():
        for _,name,mapping in refs(doc.nodes):
            if mapping.value=='army' and name.value==OWNER+':normal_malian':
                name.value=OWNER+':berbers_standard'
        for path,node in rgd.flatten(doc.nodes):
            if isinstance(node.value,str) and node.value.startswith('garrison\\berbers\\flag'):
                # Reuse the existing cooked Berber emblem for this trial. The
                # authoring profile's optional flag suite has not been authored.
                node.value='berbers'

    attributes=[]
    payload=WORK/'prepared'
    for member,doc in sorted(converted.items()):
        raw=encode(doc)
        target=payload/member
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
        attributes.append({'member':member,'file':str(target),'sha256':sha(raw)})
    owned_final={key(m) for m in converted}
    missing=[]
    for member,doc in converted.items():
        for path,name,mapping in refs(doc.nodes):
            if name.value.startswith(OWNER+':'):
                ident=(mapping.value.replace('\\','/'),name.value.split(':',1)[1])
                if ident not in owned_final:
                    missing.append([member,path,ident])
    assert not missing, missing[:25]

    # Original locale IDs are retained. The profile reserves 5000+ for new UI.
    generated=ucs_entries((WORK/'core-members/en/en.ucs').read_bytes())
    for file in (WORK/'baseline-locales').rglob('*.ucs'):
        old=ucs_entries(file.read_bytes())
        for number,text in generated.items():
            if number<5000:
                continue
            assert number not in old or old[number]==text
            old[number]=text
        target=payload/file.relative_to(WORK/'baseline-locales')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(('\r\n'.join(str(n)+'\t'+t for n,t in sorted(old.items()))+'\r\n').encode('utf-16'))

    save(WORK/'audit/migration-edits.json',{'duplicates_collapsed':aliases,'attribute_edits':edits,
         'generated_core_definitions':5,'codex':'stock Malian layout with owned references; custom additions not yet laid out',
         'army':'accepted starting tables, direct native spawning; donor start StateTree disabled',
         'own_membership':'all private EBP/SBP race membership rebased; enemy requirements preserved'})
    save(WORK/'attributes.json',attributes)
    save(WORK/'owned-index.json',{'/'.join(k):m for k,(m,_) in source.items()})
    print('PREPARED',len(attributes),'attributes; duplicate aliases',len(aliases),'owner',OWNER,flush=True)
    return attributes


if __name__=='__main__':
    prepare()
