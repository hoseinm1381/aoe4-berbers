"""Check every old custom startup handler has an independent entry path."""
import json
import re
from pathlib import Path
import prepare_trial as p


def definitions(text):
    markers=list(re.finditer(r'^function\s+([\w]+)\s*\([^\n]*',text,re.M))
    return {m.group(1):text[m.start():markers[i+1].start() if i+1<len(markers) else len(text)]
            for i,m in enumerate(markers)}


def coverage(dispatcher):
    defs={}
    roots=['BerbersPilot_Start']
    for name in re.findall(r'import\("([^"\n]+)"\)',dispatcher):
        file=p.ROOT/'source/scar'/name
        if not file.is_file():
            continue
        text=file.read_text(encoding='utf8')
        defs.update(definitions(text))
        for module in re.findall(r'Core_RegisterModule\("(\w+)"\)',text):
            if module+'_Start' in defs:
                roots.append(module+'_Start')
    defs.update(definitions(dispatcher))
    seen=set()
    def visit(name):
        if name in seen:
            return
        seen.add(name)
        if name in defs:
            body=defs[name].split('\n',1)[1] if '\n' in defs[name] else ''
            # Include one-line Core callbacks as well as multi-line functions.
            body=re.sub(r'^function\s+\w+\s*\([^)]*\)','',defs[name],count=1)
            for called in re.findall(r'\b(\w+)\s*\(',body):
                if called in defs:
                    visit(called)
    for root in roots:
        visit(root)
    return seen,roots


def main():
    legacy=(p.WORK/'baseline-scripts/scar/winconditions/berber_future_kingdom_gm.scar').read_text(encoding='utf-8-sig')
    segment=legacy.split('-- new stuff from here',1)[1].split('-- Callback invoked by Core_OnGameOver()',1)[0]
    expected=set(re.findall(r'\b(\w+)\s*\(\s*\)',segment))
    # MehariBuff_Init is a differently named native module initializer, and is
    # included from the actual old StandardMode_Start text above.
    current=(p.ROOT/'source/scar/garrison/berbers/dispatcher.scar').read_text()
    seen,roots=coverage(current)
    missing=sorted(expected-seen)
    # Reproduce the pre-fix entry paths without mutating source files. The
    # original keep file had callbacks but never registered its Core module.
    old=(p.WORK/'build-002/readback/scar/garrison/berbers/dispatcher.scar').read_text()
    old_seen,old_roots=coverage(old)
    if 'AlmohadGrandKeep_Start' in old_roots:
        old_seen.discard('Almohad_Grand_Keep_start')
    old_missing=sorted(expected-old_seen)
    report={'legacy_start_handlers':sorted(expected),'core_start_roots':roots,
            'missing_current_handlers':missing,'pre_fix_missing_handlers':old_missing,
            'limits':'Static call-path coverage; does not execute SCAR or prove handler effects.'}
    p.save(p.WORK/'audit/lifecycle-regression.json',report)
    assert not missing,missing
    assert set(old_missing)=={'Almohad_Grand_Keep_start','MehariBuff_Init','Zenata_Lancer_start','tribal_camel_archer_start'},old_missing
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
