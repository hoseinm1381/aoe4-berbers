"""Apply one reviewed SCAR registration fix and fully verify all archive bytes."""
import copy
import hashlib
import json
import shutil
from pathlib import Path
import prepare_trial as p


def main():
    original=p.WORK/'build-003'
    previous=json.loads((original/'report.json').read_text())
    recipe=json.loads((p.ROOT/'build-recipe.json').read_text())
    work=p.WORK/'finalized'
    assert not work.exists(),work
    work.mkdir()
    patch='scar/buildings/almohad_grand_keep.scar'
    changes={}
    for row in recipe['members']:
        if row['member']==recipe['dispatcher']:
            continue # assembler prepends the verified loading-phase inventory
        if row['sha256']!=previous['members'][row['member']]['sha256']:
            changes[row['member']]=Path(row['file']).read_bytes()
    assert set(changes)=={patch},set(changes)
    game=p.stock_game.current()
    archive=game.archiver.set_members(Path(previous['archive']),changes,work/'graft',toc='data')
    final=work/'berbers.sga'
    shutil.copyfile(archive,final)
    listing=game.archiver.run(['list',str(final),'--verify'])
    p.save(work/'list.json',listing)
    assert listing['archive']['name']==p.OWNER
    assert listing['archive']['verification']['verified'] is True
    expected=copy.deepcopy(previous['members'])
    expected[patch]={'toc':'data','sha256':p.sha(changes[patch]),'bytes':len(changes[patch])}
    actual={r['path']:r for r in listing['members']}
    assert set(actual)==set(expected)
    game.archiver.run(['extract',str(final),str(work/'readback'),'--filter',''])
    for member,row in expected.items():
        assert actual[member]['toc']==row['toc'],member
        raw=(work/'readback'/member).read_bytes()
        assert p.sha(raw)==row['sha256'],member
    report=copy.deepcopy(previous)
    report.update(archive=str(final),sha256=hashlib.file_digest(final.open('rb'),'sha256').hexdigest(),members=expected)
    report['finalization']={'source_archive_sha256':previous['sha256'],
           'allowlist':[patch],'reason':'Register existing AlmohadGrandKeep Core Start/OnGameOver callbacks',
           'all_members_read_back':len(expected),'untouched_members_identical':len(expected)-1,
           'stored_crc_sha1_verified':True}
    p.save(work/'report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k in ('archive','sha256','owner','finalization')},indent=2),flush=True)


if __name__=='__main__':
    main()
