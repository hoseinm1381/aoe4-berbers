"""Reviewed trial.3 additive graph, presentation and SCAR migration.

Original composed art and audio remain byte-identical. Native derived-blueprint
IDs are used only as identities; custom gameplay is kept from the tested pilot.
"""
import collections, copy, hashlib, json, re
from pathlib import Path
import prepare_trial as p

BASE=p.ROOT/'output/dropdown-fix/build/readback'
OUT=p.ROOT/'output/trial3/prepared'
AUDIT=p.ROOT/'output/trial3-audit'
SRC=p.ROOT/'source/trial3'
VERSION='0.1.0-trial.3'
PREFIX='garrison\\berbers\\presentation\\'
BONUSES=[
 ('Tribal Tents','Build a Tribal Tent each Age to form Sanhaja, Zenata or Masmuda alliances and unlock their specialist units. Military spending near a Tent earns influence toward free Villagers.'),
 ('Nomadic Trade Network','Town Centers, Markets, Mills, Lumber Camps, Mining Camps and Docks cost 10% less Wood.'),
 ('Enduring Generations','From the Feudal Age onward, economic and military units gain 5% maximum Health. This bonus does not increase further with each Age.'),
 ('Tribal Alliances','Sanhaja grants 20% more Wood on drop-off; Zenata grants 20% more Food; Masmuda grants 20% more Gold and Stone at the corresponding drop-off buildings.'),
 ('Tribal Reforms and Dynasties','Research Tribal Reforms in the Castle Age and Dynasties in the Imperial Age to develop alliance units and technologies.'),
 ('Unique Units','Tuareg Spearman, Mehari Rider, Sanhaja Camel Archer, Zenata Lancer, Masmuda Crossbowman and Almohad Handgunner. Saharan Traders support the trading economy.'),
]

def put(path,raw):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);return path

def scalar(nodes,path,value):
 n=p.rgd.find(nodes,path);assert n is not None,path;n.value=value

def setref(node,fam,name):
 p.child(node,'$PBGNAME').value=name;p.child(node,'$PBGMAP').value=fam

def main():
 prior=json.loads((p.ROOT/'output/dropdown-fix/build/report.json').read_text())
 identities=json.loads((AUDIT/'private-identities.json').read_text())
 mapping={p.key(r['member']):r for r in identities}
 by_old_member={r['member']:r for r in identities}
 names={old:row['new_name'] for (fam,old),row in mapping.items()}
 for (fam,old),row in mapping.items():assert names[old]==row['new_name']
 own={p.key(m) for m,r in prior['members'].items() if r['toc']=='attrib' and m.count('/')>=2}
 def renamed(fam,name):
  if name.startswith(p.OWNER+':'):
   short=name.split(':',1)[1]
   if (fam,short) in mapping:return p.OWNER+':'+mapping[fam,short]['new_name']
  return name
 records={}; numeric_preserved=0; changed=[];opaque=[]
 for member,row in prior['members'].items():
  if row['toc']!='attrib':continue
  raw=(BASE/member).read_bytes();doc=p.rgd.read(raw)
  oldleaves={q:(n.kind,n.value) for q,n in p.rgd.flatten(doc.nodes) if n.kind in ('Float','Int','Boolean') and n.key!='pbgid'}
  if member in by_old_member:
   ident=by_old_member[member]
   for q,n in p.rgd.flatten(doc.nodes):
    if n.key=='pbgid':n.value=ident['new_id']
   member=member.rsplit('/',1)[0]+'/'+ident['new_name']+'.rgd'
  for path,n,m in p.refs(doc.nodes):
   n.value=renamed(m.value.replace('\\','/'),n.value)
  # Typed refs own the runtime lookup graph. Any other exact qualified PBG
  # literals are audited separately before changing them, never substring art.
  for q,n in p.rgd.flatten(doc.nodes):
   if n.kind=='CString' and isinstance(n.value,str) and n.value.startswith(p.OWNER+':') and n.key!='$PBGNAME':opaque.append((member,q,n.value))
  newleaves={q:(n.kind,n.value) for q,n in p.rgd.flatten(doc.nodes) if n.kind in ('Float','Int','Boolean') and n.key!='pbgid'}
  assert oldleaves==newleaves,member
  numeric_preserved+=len(oldleaves)
  records[member]=doc
 race_member=next(m for m in records if m.startswith('attrib/racebps/'))
 army_member=next(m for m in records if m.startswith('attrib/army/'))
 codex_member=next(m for m in records if m.startswith('attrib/codex/'))
 # Native presentation references are relative to ui/images, unlike UI icons.
 surfaces={'icon':'flag_list_t3','icon_small':'','icon_secondary':'flag_secondary_t3',
 'icon_secondary_small':'flag_secondary_small_t3','flag_icon':'flag_fade_t3',
 'image':'flag_loading_t3','image_small':'flag_background_t3','pattern':'flag_pattern_t3',
 'tile':'flag_tile_t3','mastery_flag':'flag_mastery_t3'}
 for path,n in p.rgd.flatten(records[race_member].nodes):
  if '/race_bag/' in path:
   field=path.rsplit('/',1)[-1]
   if field in surfaces:n.value=PREFIX+surfaces[field] if surfaces[field] else ''
 # Keep original localization IDs, replacing only obsolete independent-lobby
 # instructions and authoring placeholders. Add per-bonus native traits.
 ucs=p.ucs_entries((BASE/'en/en.ucs').read_bytes())
 description=('The Berber Dynasties unite the tribes of the Maghreb through mobile armies, tribal alliances and trade. '
              'Establish Tribal Tents, develop your chosen alliances and field specialist desert warriors.')
 ucs.update({5000:'Berbers',5001:description,5002:'980 - 1549 CE',5003:'Tribal Tents, Alliances, Mobile Armies',
             5004:'Civilization Bonuses',5005:'\\n'.join('• '+v for _,v in BONUSES)})
 ucs[2]=description+'\\n\\nSelect Berbers in the civilization dropdown. Use Standard and Tuning Pack: None.\\n\\n'+'\\n\\n'.join(k+'\\n'+v for k,v in BONUSES)
 for path,n in p.rgd.flatten(records[army_member].nodes):
  if path.endswith('/army_bag/ui/difficulty'):n.value=3
  elif path.endswith('/army_bag/ui/background_image'):n.value=PREFIX+'flag_secondary_t3'
  elif path.endswith('/global_traits_summary/trait/icon'):n.value=PREFIX+'flag_list_small_t3'
 for variant in p.rgd.tables(records[army_member].nodes):
  group=p.rgd.find(records[army_member].nodes,variant+'/army_bag/ui/global_traits_summary')
  if group is None:continue
  template=copy.deepcopy(group.value[0]); group.value=group.value[:1]
  for i,(title,desc) in enumerate(BONUSES):
   tid=5010+i*2;did=tid+1;ucs[tid]=title;ucs[did]=desc
   trait=copy.deepcopy(template)
   p.child(trait,'title').value='$'+p.OWNER+':'+str(tid)
   p.child(trait,'description').value='$'+p.OWNER+':'+str(did)
   p.child(trait,'icon').value=PREFIX+'flag_list_small_t3'
   fmt=p.child(trait,'description_formatter')
   if fmt:
    for c in fmt.value:
     if isinstance(c.value,list):c.value=[]
     elif c.kind=='CString':c.value=''
     elif c.kind=='Int':c.value=0
   group.value.append(trait)
 # Build Codex from actual menus. Both native representations are replaced.
 codex_report=build_codex(records,codex_member,renamed)
 # A rebased Malian RaceBP still advertised Donso as its spearman and left
 # Berber crossbow/knight slots empty. Reconcile catalogue references with the
 # actual roster, retaining intentional stock farms/walls from construction.
 roster=json.loads((AUDIT/'berber-codex-roster.json').read_text())
 reachable={tuple(i) for i in roster['reachable']}
 archetype_edits=[]
 replacements={'spearman':('sbps',p.OWNER+':unit_spearman_tuareg_1_ber'),
 'crossbowman':('sbps',p.OWNER+':unit_masmuda_cb_2_ber'),
 'knight':('sbps',renamed('sbps',p.OWNER+':unit_knight_3_song_cmp')),
 'ship_springald':('sbps',renamed('sbps',p.OWNER+':unit_naval_combat_ship_2_abb')),
 'ship_warship':('sbps',renamed('sbps',p.OWNER+':unit_naval_combat_warship_4_abb'))}
 for variant in p.rgd.tables(records[race_member].nodes):
  archetypes=p.rgd.find(records[race_member].nodes,variant+'/race_bag/blueprint_archetypes')
  for node in archetypes.value:
   name=p.child(node,'$PBGNAME');family=p.child(node,'$PBGMAP')
   if name is None:continue
   old=(family.value,name.value)
   if node.key in replacements and replacements[node.key] in reachable:
    setref(node,*replacements[node.key])
   elif node.key=='manatarms' and name.value.endswith(':ber_unit_gbeto_2_mal') and (family.value,name.value) not in reachable:
    setref(node,'','')
   if old!=(family.value,name.value):archetype_edits.append([variant,node.key,old,(family.value,name.value)])
 p.save(AUDIT/'archetype-reconciliation.json',archetype_edits)
 # Every imported active SCAR uses private names; preserve short-name lookups
 # in voice maps and normalize the three BP_GetName comparison consumers.
 id_changes={r['id']:r['new_id'] for r in identities if p.key(r['member'])[0] in ('ebps','sbps')}
 script_report=[]
 for source in (p.ROOT/'source/scar').rglob('*.scar'):
  member=source.relative_to(p.ROOT/'source').as_posix()
  text=source.read_text(encoding='utf8');old=text
  # Exact blueprint literal names; never rewrite resource filenames or tags.
  def literal(m):
   v=m.group(2)
   if v.startswith(p.OWNER+':') and v.split(':',1)[1] in names:v=p.OWNER+':'+names[v.split(':',1)[1]]
   elif v in names:v=names[v]
   return m.group(1)+v+m.group(1)
  text=re.sub(r'([\"\'])([^\"\'\r\n]*)\1',literal,text)
  for oldid,newid in id_changes.items():text=re.sub(r'(?<![\w.])'+str(oldid)+r'(?![\w.])',str(newid),text)
  if member=='scar/inflence_system.scar':
   # Constants serve both BP resolution and name checks, so compare against
   # the documented short part without weakening the private lookup itself.
   text=text.replace('BP_GetName(ebp) ~= INFLUENCE_FUNDUQ_BP_NAME','BP_GetName(ebp) ~= string.match(INFLUENCE_FUNDUQ_BP_NAME, "[^:]+$")')
   text=text.replace('name == INFLUENCE_FUNDUQ_BP_NAME','name == string.match(INFLUENCE_FUNDUQ_BP_NAME, "[^:]+$")')
   text=text.replace('name == INFLUENCE_TENT_BP_NAME','name == string.match(INFLUENCE_TENT_BP_NAME, "[^:]+$")')
   text=text.replace(' or Entity_IsOfType(entity, "spirit_way")','')
   text=text.replace('    local squad = context.spawnedSquad',
    '    if Player_GetRaceName(context.player) ~= "'+p.RACE+'" then return end\n\n    local squad = context.spawnedSquad')
  elif member=='scar/units/sanhaja_buff.scar':
   text=text.replace('string.find(built_bp_name, "'+p.OWNER+':','string.find(built_bp_name, "')
  elif member=='scar/buildings/tent_ui.scar':
   text=re.sub(r'(\.name == ")'+p.OWNER+':',r'\1',text)
  elif member=='scar/garrison/berbers/dispatcher.scar':
   text=text.replace('version=0.1.0-trial.1','version='+VERSION)
   # Bounded diagnostics identify actual spawned squads in the next owner test.
   text=text.replace('function BerbersPilot_Start()',starter_diagnostics(mapping)+'\nfunction BerbersPilot_Start()')
   text=text.replace('    Nomadic_Trade_Network_start()','    BerbersPilot_LogStarters()\n    Nomadic_Trade_Network_start()')
  elif member=='scar/passive_bonus/nomadic_trade_network.scar':
   text='Core_RegisterModule("BerbersNomadicTrade")\n'+text
   text=text.replace('_nomadic_trade_network.started = true','_nomadic_trade_network.started = true\n    _nomadic_trade_network.modifiers = {}')
   text=text.replace('Modifier_ApplyToPlayer(modifier, player_id, 0.0)','Modifier_ApplyToPlayer(modifier, player_id, 0.0)\n                        table.insert(_nomadic_trade_network.modifiers, modifier)')
   text+='''
function BerbersNomadicTrade_OnGameSetup()
    _nomadic_trade_network.started=false
    _nomadic_trade_network.modifiers={}
end
function BerbersNomadicTrade_OnGameOver()
    for _,modifier in ipairs(_nomadic_trade_network.modifiers or {}) do
        Modifier_RemoveInternal(modifier.ModifierID)
    end
    _nomadic_trade_network.modifiers={}
    _nomadic_trade_network.started=false
end
'''
  elif member=='scar/passive_bonus/enduring_generations.scar':
   text='Core_RegisterModule("BerbersEnduringGenerations")\n'+text
   text+='''
function BerbersEnduringGenerations_OnGameSetup()
    _enduring_generations.started=false
    _enduring_generations.blueprints_initialized=false
    _enduring_generations.unit_blueprints={}
    _enduring_generations.player_states={}
end
function BerbersEnduringGenerations_OnGameOver()
    Rule_Remove(Enduring_Generations_Reconcile)
    for _,state in pairs(_enduring_generations.player_states) do
        Enduring_Generations_RemovePlayerModifiers(state)
    end
    _enduring_generations.player_states={}
    _enduring_generations.started=false
end
'''
  elif member=='scar/buildings/tribal_tent.scar':
   text+='''
-- A second fresh match must retain its free first alliance choice.
function TribalTent_OnGameSetup()
    _tribal_tent.started=false
    _tribal_tent.switch_cost_applied={}
end
'''
   text=text.replace('Rule_RemoveGlobalEvent(TribalTent_OnAbilityExecuted)\n',
    'Rule_RemoveGlobalEvent(TribalTent_OnAbilityExecuted)\n    _tribal_tent.switch_cost_applied={}\n')
  elif member=='scar/buildings/alliance_economic_bonus.scar':
   text=text.replace('Rule_RemoveGlobalEvent(AllianceEcon_OnAbilityExecuted)\n',
    '''Rule_RemoveGlobalEvent(AllianceEcon_OnAbilityExecuted)
    for _,mods in pairs(_alliance_econ.player_modifiers) do
        for _,applied in ipairs(mods) do Modifier_Remove(applied) end
    end
    _alliance_econ.player_modifiers={}
''')
   text+='''
function AllianceEconomicBonus_OnGameSetup()
    _alliance_econ.started=false
    _alliance_econ.player_modifiers={}
end
'''
  target=put(SRC/member,text.encode('utf8'))
  script_report.append({'member':member,'file':str(target),'changed':text!=old,'sha256':p.sha(target.read_bytes())})
 # Native cooked UI uses both images (race/army) and icons (bonus traits).
 game=p.stock_game.current();carrier=p.ROOT/'authoring-library/Mods/berbers/dist/berbers.sga'
 ui_members=[]
 for row in game.archiver.members(carrier):
  member=row['path']
  if member.startswith(('ui/images/garrison/berbers/presentation/','ui/icons/garrison/berbers/presentation/')) and member.endswith('.rrtex'):
   raw=game.archiver.read(carrier,member);f=put(OUT/member,raw)
   ui_members.append({'member':member,'file':str(f),'toc':'data','sha256':p.sha(raw)})
 assert len(ui_members)==20,len(ui_members)
 attributes=[]
 for member,doc in records.items():
  raw=p.encode(doc);file=put(OUT/member,raw)
  attributes.append({'member':member,'file':str(file),'sha256':p.sha(raw)})
 recipe=json.loads((p.ROOT/'build-recipe.json').read_text())
 recipe['attributes']=attributes
 scripts={r['member']:r for r in script_report}
 members=[]
 for row in recipe['members']:
  if row['member'] in scripts:row={k:v for k,v in scripts[row['member']].items() if k!='changed'};row['toc']='data'
  if row['member'].endswith('.ucs'):
   raw=('\r\n'.join(str(i)+'\t'+t for i,t in sorted(ucs.items()))+'\r\n').encode('utf-16')
   file=put(OUT/row['member'],raw);row=dict(row,file=str(file),sha256=p.sha(raw))
  members.append(row)
 members.extend(ui_members);recipe['members']=members
 recipe['shared_entities']=sorted({n.value for doc in records.values() for q,n,m in p.refs(doc.nodes) if m.value=='ebps' and ':' not in n.value})
 p.save(p.ROOT/'trial3-build-recipe.json',recipe)
 p.save(AUDIT/'preparation.json',{'version':VERSION,'native_allocated_private_records':len(identities),
  'imported_numeric_boolean_leaves_preserved_before_presentation':numeric_preserved,'opaque_qualified_strings':opaque,
  'scripts':script_report,'codex':codex_report,'archetype_edits':archetype_edits,'bonuses':BONUSES,'surface_fields':surfaces})
 print('PREPARED',len(attributes),'attributes',len(members),'members',len(identities),'native identities',flush=True)

def starter_diagnostics(mapping):
 ids={old:row['new_id'] for (fam,old),row in mapping.items() if fam=='sbps' and old in ('unit_villager_1_mal','unit_scout_1_mal')}
 return '''function BerbersPilot_LogStarters()
    local player=Game_GetLocalPlayer()
    if player==nil or Player_GetRaceName(player)~="'''+p.RACE+'''" then return end
    local squads=Player_GetSquads(player) -- borrowed group; do not destroy
    for i=1,SGroup_Count(squads) do
        local squad=SGroup_GetSquadAt(squads,i)
        local bp=Squad_GetBlueprint(squad)
        if bp then print("BERBERS_TRIAL3_STARTER name="..BP_GetName(bp).." pbgid="..tostring(bp.PropertyBagGroupID)) end
    end
    print("BERBERS_TRIAL3_EXPECT villager='''+str(ids['unit_villager_1_mal'])+' scout='+str(ids['unit_scout_1_mal'])+'''")
end
'''

def build_codex(records,member,renamed):
 """Production-derived native display; conditional requirements stay on records."""
 doc=records[member]
 index={p.key(m):d for m,d in records.items() if m.count('/')>=2}
 def refident(n,m):return (m.value.replace('\\','/'),n.value)
 graph={};edges=[]
 for m,d in records.items():
  if m.count('/')<2 or p.family(m) not in ('ebps','sbps'):continue
  ident=(p.family(m),p.OWNER+':'+Path(m).stem)
  children=[]
  for q,n,mp in p.refs(d.nodes):
   if not q.startswith('default/'):continue
   if ('/squad_engineer_ext/construction_groups/' in q and mp.value=='ebps') or ('/spawner_ext/spawn_items/' in q and mp.value=='sbps') or ('/upgrade_ext/standard_upgrades/' in q and mp.value=='upgrade'):
    target=refident(n,mp)
    if target not in children:children.append(target)
  if children:graph[ident]=children
 builder=renamed('sbps',p.OWNER+':unit_villager_1_mal')
 capital=renamed('ebps',p.OWNER+':building_town_center_capital_mal')
 roots=[('sbps',builder),('ebps',capital)]
 reachable=set();queue=list(roots)
 while queue:
  ident=queue.pop(0)
  if ident in reachable:continue
  reachable.add(ident)
  for child in graph.get(ident,[]):edges.append((ident,child));queue.append(child)
 # Include the actual age-tier upgrade targets, which are referenced by upgrade
 # actions rather than the producer's initial spawn list.
 for m,d in records.items():
  if m.count('/')>=2 and p.family(m)=='upgrade' and ('upgrade',p.OWNER+':'+Path(m).stem) in reachable:
   for q,n,mp in p.refs(d.nodes):
    if q.startswith('default/') and mp.value=='sbps' and n.value.startswith(p.OWNER+':'):
     reachable.add(('sbps',n.value))
 def age(ident):
  fam,name=ident;short=name.split(':')[-1];short=short.removeprefix('ber_')
  # Data requirements take precedence over suffixes.
  d=index.get((fam,name.split(':')[-1]))
  values=[]
  if d:
   for q,n in p.rgd.flatten(d.nodes):
    if q.startswith('default/') and '/requirements/' in q and n.key=='$PBGNAME':
     values.append(n.value.split(':')[-1])
  for stage,level in [('imperial_age',4),('castle_age',3),('feudal_age',2)]:
   if stage in values:return level
  lm=re.search(r'landmark_age([123])',short)
  if lm:return int(lm[1])+1
  unit=re.search(r'_(?:age)?([1-4])(?:_|$)',short)
  return int(unit[1]) if unit else 1
 native_rows=[]
 for variant in p.rgd.tables(doc.nodes):
  bag=p.rgd.find(doc.nodes,variant+'/codex_bag')
  if bag is None:continue
  unique=p.child(bag,'unique_units');pbtemplate=copy.deepcopy(unique.value[0])
  uniques=[i for i in sorted(reachable) if i[0]=='sbps' and any(t in i[1] for t in ('tuareg','mehari_','sanhaja_ca','masmuda_cb','unit_horseman_','unit_handcannon_','unit_trade_cart'))]
  # Show one initial card per unique family, including the explicitly named
  # Feudal/Castle/Imperial units; upgrade tiers remain in the main native tree.
  chosen=[];families=set()
  for ident in sorted(uniques,key=lambda i:(age(i),i[1])):
   family=re.sub(r'_[1-4](?=_)','_tier',ident[1])
   if family not in families:chosen.append(ident);families.add(family)
  unique.value=[]
  for fam,name in chosen:
   node=copy.deepcopy(pbtemplate);setref(node,fam,name);unique.value.append(node)
  tree=p.child(bag,'tech_tree');gtemplate=copy.deepcopy(tree.value[0]);ittemplate=copy.deepcopy(p.child(gtemplate,'items').value[0]);tree.value=[]
  # One producer branch per building, using stock native item templates.
  producers=[i for i in sorted(reachable) if i[0]=='ebps' and (i in graph or 'landmark_' in i[1])]
  root=p.child(bag,'root_item');defaulttemplate=copy.deepcopy(p.child(root,'children').value[0])
  p.child(root,'children').value=[];setref(p.child(root,'pbg'),'sbps',builder)
  for col,producer in enumerate(producers):
   group=copy.deepcopy(gtemplate);items=p.child(group,'items');items.value=[]
   p.child(group,'background_template').value='economic' if any(t in producer[1] for t in ('econ_','town_center','house','hut')) else 'military'
   p.child(group,'background_height').value=12
   branch=copy.deepcopy(defaulttemplate);p.child(branch,'children').value=[];setref(p.child(branch,'pbg'),*producer)
   scalar(branch.value,'ui_codex_info/ui_position/ui_position_column',col+1)
   scalar(branch.value,'ui_codex_info/ui_position/ui_position_row',-1)
   branchitems=[producer]+graph.get(producer,[])
   # Add owned age-tier unit equivalents for the actual produced families.
   for ident in sorted(reachable):
    if ident[0]!='sbps' or ident in branchitems:continue
    stem=re.sub(r'_[1-4](?=_)','_tier',ident[1])
    if any(t[0]=='sbps' and re.sub(r'_[1-4](?=_)','_tier',t[1])==stem for t in branchitems):branchitems.append(ident)
   rowcounts=collections.Counter()
   agecounts=collections.Counter(age(i) for i in branchitems)
   for ident in branchitems:
    a=age(ident);r=(a-1)*3+rowcounts[a]%3
    # Native group coordinates are local and centered; the UI places groups.
    width=(agecounts[a]+2)//3
    x=2*(rowcounts[a]//3)-(width-1);rowcounts[a]+=1
    node=copy.deepcopy(ittemplate)
    for k in ('left_branch_length','right_branch_length','top_line_length'):p.child(node,k).value=0
    p.child(node,'x_position').value=x;p.child(node,'y_position').value=r
    setref(p.child(node,'pbg'),*ident);setref(p.child(node,'upgrade_pbg'),'','');items.value.append(node)
    native_rows.append({'producer':producer,'blueprint':ident,'age':a,'x':x,'y':r})
    if ident!=producer:
     child=copy.deepcopy(defaulttemplate);p.child(child,'children').value=[];setref(p.child(child,'pbg'),*ident)
     scalar(child.value,'ui_codex_info/ui_position/ui_position_column',len(p.child(branch,'children').value)+1)
     scalar(child.value,'ui_codex_info/ui_position/ui_position_row',-1)
     p.child(branch,'children').value.append(child)
   tree.value.append(group);p.child(root,'children').value.append(branch)
 p.save(AUDIT/'berber-codex-roster.json',{'reachable':sorted(reachable),'edges':edges,'native_items':native_rows,
 'limits':'Menu/upgrade graph presentation; alliance conditions remain on original records. Native layout/requirements are owner-test gates.'})
 return {'reachable_records':len(reachable),'producer_branches':len(producers),'unique_cards':len(chosen),'native_items_all_variants':len(native_rows)}

if __name__=='__main__':main()
