"""Static contracts and focused Lua regressions; never native-game acceptance."""
import collections, copy, io, json, re, struct
from pathlib import Path
import prepare_trial as p
from lupa import LuaRuntime
from PIL import Image, ImageChops, ImageStat
from garrison_shared import rrtex_decoder

def main():
 root=p.ROOT;audit=root/'output/trial3-audit'
 recipe=json.loads((root/'trial3-build-recipe.json').read_text())
 identities=json.loads((audit/'private-identities.json').read_text())
 expected={r['member'].rsplit('/',1)[0]+'/'+r['new_name']+'.rgd':r for r in identities}
 docs={r['member']:p.rgd.read(Path(r['file']).read_bytes()) for r in recipe['attributes']}
 owned={p.key(m) for m in docs if m.count('/')>=2}
 all_ids=collections.defaultdict(set);numeric=0;refs=0;stale=[]
 before=root/'output/dropdown-fix/build/readback'
 core=('racebps','army','codex','army_slot_layout','statemodel_schema')
 for member,doc in docs.items():
  for q,n in p.rgd.flatten(doc.nodes):
   if n.key=='pbgid':all_ids[(p.family(member) if member.count('/')>=2 else 'root',n.value)].add(member)
   if isinstance(n.value,str) and p.OLD in n.value:stale.append((member,q,n.value))
  for q,n,m in p.refs(doc.nodes):
   refs+=1
   if n.value.startswith(p.OWNER+':'):assert (m.value.replace('\\','/'),n.value.split(':',1)[1]) in owned,(member,q,n.value)
  if member.count('/')<2 or p.family(member) in core:continue
  oldmember=expected.get(member,{}).get('member',member)
  previous=p.rgd.read((before/oldmember).read_bytes())
  def numbers(nodes):return {q:(n.kind,n.value) for q,n in p.rgd.flatten(nodes) if n.kind in ('Int','Float','Boolean') and n.key!='pbgid'}
  orig,after=numbers(previous.nodes),numbers(doc.nodes)
  assert orig==after,member;numeric+=len(orig)
 assert not stale,stale[:10]
 assert all(len(v)==1 for v in all_ids.values()),[(k,v) for k,v in all_ids.items() if len(v)>1]
 for r in identities:
  assert (p.key(r['member'])[0],r['new_name']) in owned
  assert (p.key(r['member'])[0],Path(r['member']).stem) not in owned
  assert r['new_id']!=r['stock_id']
 vm=LuaRuntime(unpack_returned_tuples=True)
 compiler=vm.eval('function(code,name) local f,e=load(code,name); return f~=nil,e end')
 scripts=[]
 for row in recipe['members']:
  f=Path(row['file']);assert p.sha(f.read_bytes())==row['sha256'],f
  if row['member'].endswith('.scar'):
   code=f.read_text(encoding='utf-8-sig');ok,error=compiler(code,row['member']);assert ok,(row['member'],error)
   assert p.OLD not in code
   scripts.append(row['member'])
 # Execute actual native-name predicate bodies with only the engine boundary
 # stubbed. The old trial must reject the same valid short-name tent/landmark.
 def influence_test(file,short,spirit=False):
  code=file.read_text(encoding='utf8')
  constants=code.split('local INFLUENCE_SYSTEM_RANGE',1)[1].split('-- Module state',1)[0]
  constants='local INFLUENCE_SYSTEM_RANGE'+constants
  start=code.index('local function IS_IsFunduq(')
  end=code.index('local function IS_PlayerHasFunduq(',start)
  body=code[start:end]
  lua=LuaRuntime(unpack_returned_tuples=True)
  lua.execute('''function Entity_GetID(e) return 1 end
function Entity_IsValid(id) return true end
function Entity_GetBlueprint(e) return e end
function BP_GetName(e) return e.name end
function Entity_IsAlive(e) return true end
function Entity_GetBuildingProgress(e) return 1 end
function Entity_GetStateModelBool(e,k) return true end
function Entity_IsOfType(e,k) return e.spirit==true end''')
  fn=lua.execute(constants+'\n'+body+'\nreturn function(name,spirit) local e={name=name,spirit=spirit}; return IS_IsTent(e),IS_IsFunduq(e) end')
  return fn(short,spirit)
 oldshort='building_landmark_age1_landmarkb_mal'
 newshort=next(r['new_name'] for r in identities if p.key(r['member'])==('ebps',oldshort))
 old_test=influence_test(root/'source/scar/inflence_system.scar',oldshort)
 new_test=influence_test(root/'source/trial3/scar/inflence_system.scar',newshort)
 assert old_test==(False,False),old_test
 assert new_test==(True,True),new_test
 tent=next(r['new_name'] for r in identities if p.key(r['member'])==('ebps','building_hut_ayy'))
 assert influence_test(root/'source/trial3/scar/inflence_system.scar',tent)==(True,False)
 foreign='building_landmark_age3_landmarka_control_chi'
 assert influence_test(root/'source/scar/inflence_system.scar',foreign,True)==(True,False)
 assert influence_test(root/'source/trial3/scar/inflence_system.scar',foreign,True)==(False,False)
 # A foreign training event must exit before any squad/cost/group work.
 source=(root/'source/trial3/scar/inflence_system.scar').read_text()
 handler=source.split('function InfluenceSystem_OnBuildItemComplete(context)',1)[1].split('-- Public lifecycle',1)[0]
 lua=LuaRuntime(unpack_returned_tuples=True)
 lua.execute('''_IS={started=true}
function Player_GetRaceName(player) return "chinese" end
function Squad_GetID(squad) error("foreign squad was touched") end
function InfluenceSystem_OnBuildItemComplete(context)'''+handler)
 lua.globals().InfluenceSystem_OnBuildItemComplete(lua.table_from({'player':1,'pbg':1,'spawnedSquad':1}))
 # Execute passive startup/end/setup twice in one Lua VM: idempotent starts,
 # tracked modifier cleanup and a fresh second-match application.
 lifecycle={}
 for filename,start,setup,stop in [
  ('nomadic_trade_network','Nomadic_Trade_Network_start','BerbersNomadicTrade_OnGameSetup','BerbersNomadicTrade_OnGameOver'),
  ('enduring_generations','Enduring_Generations_start','BerbersEnduringGenerations_OnGameSetup','BerbersEnduringGenerations_OnGameOver')]:
  lua=LuaRuntime(unpack_returned_tuples=True)
  lua.execute('''created=0;removed=0;intervals=0
function Core_RegisterModule(n) end
function World_GetPlayerCount() return 1 end
function World_GetPlayerAt(i) return i end
function Player_IsAlive(p) return true end
function Player_GetRaceName(p) return "'''+p.RACE+'''" end
function BP_GetEntityBlueprintsWithType(t) return {{PropertyBagGroupID=100}} end
function BP_GetUpgradeBlueprint(n) return n end
function Player_HasUpgrade(p,n) return n=="feudal_age" end
function Modifier_Create(...) created=created+1; return {ModifierID=created} end
function Modifier_ApplyToPlayer(...) end
function Modifier_RemoveInternal(id) removed=removed+1 end
function Rule_AddInterval(...) intervals=intervals+1 end
function Rule_Remove(...) intervals=intervals-1 end''')
  lua.execute((root/'source/trial3/scar/passive_bonus'/(filename+'.scar')).read_text())
  g=lua.globals();g[setup]();g[start]();initial=g.created;g[start]();assert g.created==initial
  g[stop]();assert g.removed==initial
  g[setup]();g[start]();assert g.created==initial*2
  g[stop]();assert g.removed==initial*2
  lifecycle[filename]={'initial_modifiers':initial,'two_match_modifiers':g.created,'removed':g.removed}
 # Verify cooked UI internals and decode BC7 using DDS DXGI98. The installed
 # decoder does not yet route internal format28; its stream/mip reader works.
 textures=[]
 for row in recipe['members']:
  if not row['member'].startswith('ui/images/garrison/berbers/presentation/'):continue
  f=Path(row['file']);doc=rrtex_decoder.load(f);nodes={n.tag:n for n in doc.walk()}
  rrtex_decoder._validate_stream_table(nodes[b'TMAN'].payload,nodes[b'TDAT'].payload)
  _,mips=rrtex_decoder._decode_mips(nodes[b'TDAT'].payload)
  assert len(mips)==1,(row['member'],len(mips))
  internal=nodes[b'TXTR'].name.rstrip(b'\0').decode().replace('\\','/')
  assert internal==row['member'][:-6],(internal,row['member'])
  png=root/'source/presentation/trial3'/(Path(row['member']).stem+'.png')
  source=Image.open(png).convert('RGBA')
  decoded=Image.open(io.BytesIO(rrtex_decoder._dds(mips,98))).convert('RGBA')
  assert source.size==decoded.size,(row['member'],source.size,decoded.size)
  error=ImageStat.Stat(ImageChops.difference(source,decoded)).mean
  flipped=ImageStat.Stat(ImageChops.difference(source,decoded.transpose(Image.Transpose.FLIP_TOP_BOTTOM))).mean
  assert max(error)<15,(row['member'],error)
  assert sum(error)<sum(flipped),(row['member'],'unexpected flip',error,flipped)
  alpha=decoded.getchannel('A').getextrema()
  if 'pattern' in row['member']:assert alpha[0]<10 and alpha[1]>200,alpha
  out=audit/'decoded-ui'/(Path(row['member']).stem+'.png');out.parent.mkdir(exist_ok=True);decoded.save(out)
  textures.append({'member':row['member'],'dimensions':source.size,'mips':1,'bc7_dds_decoded':True,'mean_absolute_rgba_error':error,'alpha':alpha})
 p.save(audit/'checks.json',{'version':'0.1.0-trial.3','attributes':len(docs),'owned_typed_references':refs,
 'private_identity_records':len(identities),'unchanged_gameplay_numeric_boolean_leaves':numeric,
 'lua_syntax_checked_files':scripts,'short_name_regression':{'old_funduq':old_test,'new_funduq':new_test},
 'cross_civ_influence_regression':True,'passive_lifecycle_regression':lifecycle,'ui_textures':textures,'native_game_acceptance':False})
 print('PASS',len(docs),'attributes;',len(scripts),'Lua files;',numeric,'unchanged gameplay leaves;',len(textures),'BC7 UI surfaces')

if __name__=='__main__':main()
