"""Prepare the pilot's scripts, byte-preserved resources and assembler recipe."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sys
import prepare_trial as p

ROOT, WORK, OWNER, RACE = p.ROOT, p.WORK, p.OWNER, p.RACE


def main():
    listing=json.loads((WORK/'audit/baseline-list.json').read_text())
    own_index=json.loads((WORK/'owned-index.json').read_text())
    own_names={name.rsplit('/',1)[1] for name in own_index}
    attributes=json.loads((WORK/'attributes.json').read_text())
    aliases={}
    by_hash={}
    candidates={}
    for file in sorted((WORK/'resources/audio').rglob('*')):
        if file.is_file():
            member=file.relative_to(WORK/'resources').as_posix()
            digest=hashlib.file_digest(file.open('rb'),'sha256').hexdigest()
            if digest in by_hash and Path(by_hash[digest]).suffix==file.suffix:
                aliases[member]=by_hash[digest]
            else:
                by_hash[digest]=member
            candidates[member]=(file,digest)
    def audio_paths(text):
        for old,new in aliases.items():
            text=text.replace(old,new)
        return text
    prepared={}
    script_edits=[]
    skipped=[]
    for file in sorted((WORK/'baseline-scripts/scar').rglob('*.scar')):
        member=file.relative_to(WORK/'baseline-scripts').as_posix()
        if member.startswith('scar/ai/') or member.startswith('scar/winconditions/') or member=='scar/modifier_test.scar':
            skipped.append(member)
            continue
        text=file.read_text(encoding='utf-8-sig')
        original=text
        text=text.replace(p.OLD+':',OWNER+':')
        text=text.replace('Garrison.audio.forMod("berber_future_kingdom")','Garrison.audio.forMod("berbers")')
        if member=='scar/music/berber_music.scar':
            text=text.replace('function BM_Start()','function BM_Start()\n    local player=Game_GetLocalPlayer()\n    if player==nil or Player_GetRaceName(player)~="'+RACE+'" then return end',1)
        if member=='scar/buildings/almohad_grand_keep.scar':
            # The old mode called its helper directly. Its existing Core Start
            # and teardown callbacks were present but the module was unregistered.
            assert 'Core_RegisterModule(' not in text
            text='Core_RegisterModule("AlmohadGrandKeep")\n'+text
        if member not in ('scar/berber_voice_bank.scar','scar/units/tuareg_voice_profile.scar','scar/garrison/garrison.scar'):
            # Exact literal identity edits. Do not touch type tags/resource paths.
            def literal(m):
                value=m.group(2)
                before=text[max(0,m.start()-20):m.start()]
                if value=='malian':
                    value=RACE
                elif value in own_names and not re.search(r'owner\s*\.\.\s*$',before):
                    value=OWNER+':'+value
                return m.group(1)+value+m.group(1)
            text=re.sub(r'([\"\'])([^\"\'\r\n]*)\1',literal,text)
        text=audio_paths(text)
        target=ROOT/'source'/member
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(text,encoding='utf8')
        prepared[member]=target
        script_edits.append({'member':member,'before':p.sha(file.read_bytes()),'after':p.sha(target.read_bytes()),
                             'changes':'owned blueprint/race identity, audio channel and lossless audio path aliases'})
    imports=[
        'units/tuareg_q_art_guard_trial.scar','units/saharan_trader.scar','units/zenata_lancer.scar',
        'units/tribal_camel_archer.scar','passive_bonus/nomadic_trade_network.scar',
        'passive_bonus/enduring_generations.scar','buildings/tribal_tent.scar','units/sanhaja_buff.scar',
        'inflence_system.scar','buildings/tent_ui.scar','buildings/alliance_economic_bonus.scar',
        'buildings/almohad_grand_keep.scar','buildings/madrasa_fez.scar',
        'buildings/great_mosque_of_tlemcen.scar','buildings/marrakech.scar','buildings/malian_house.scar',
        'berber_scripted_speech.scar','music/berber_music.scar']
    for name in imports:
        assert 'scar/'+name in prepared,name
    dispatcher='scar/garrison/berbers/dispatcher.scar'
    text='''-- Berbers independent dropdown pilot. Standard game mode owns victory/start.
import("cardinal.scar")
Core_RegisterModule("BerbersPilot")
'''+''.join('import('+json.dumps(name)+')\n' for name in imports)+'''
BerbersPilotState = {started=false}
function BerbersPilot_OnGameSetup()
    BerbersPilotState.started=false
end
function BerbersPilot_OnInit()
    for _,player in ipairs(PLAYERS) do
        print("BERBERS_PILOT_PLAYER race=" .. Player_GetRaceName(player.id))
    end
end
function BerbersPilot_Start()
    if BerbersPilotState.started then return end
    BerbersPilotState.started=true
    -- Other imported Core modules retain their own Start callbacks. Only the
    -- handlers whose callbacks are empty, plus the two passive systems, are here.
    Nomadic_Trade_Network_start()
    Enduring_Generations_start()
    Zenata_Lancer_start()
    tribal_camel_archer_start()
    tribal_tent_start()
    inflence_system_start()
    MehariBuff_Init()
    local player=Game_GetLocalPlayer()
    if player~=nil and Player_GetRaceName(player)=="__RACE__" then
        BerberSpeech_Start()
        BM_Start()
    end
    print("BERBERS_PILOT_STARTED version=0.1.0-trial.1 race=__RACE__")
end
function BerbersPilot_OnGameOver()
    BerberSpeech_Stop()
    BerbersPilotState.started=false
end
'''.replace('__RACE__',RACE)
    target=ROOT/'source'/dispatcher
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(text,encoding='utf8')
    prepared[dispatcher]=target
    members=[]
    omitted=[]
    # Explicit active route: existing PCM voices and music. The unrelated native
    # source-replacement manifest/WEM vault remains in the original rebuild inputs.
    for row in listing['members']:
        name=row['path']
        if row['toc']!='data' or name.startswith(('attrib/','scar/')):
            continue
        if name.startswith(('garrison/speech/','garrison/runtime/','garrison/author-audio/')):
            omitted.append({'member':name,'bytes':row['size'],'reason':'inactive native replacement/authoring material; scripted route retained'})
            continue
        if name in aliases:
            omitted.append({'member':name,'bytes':row['size'],'reason':'byte-identical audio alias','alias':aliases[name]})
            continue
        file=WORK/'resources'/name
        assert file.is_file(),name
        if file.suffix=='.json' and name.startswith('audio/'):
            old=file.read_text(encoding='utf-8-sig')
            updated=audio_paths(old)
            if updated!=old:
                target=WORK/'prepared'/name
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(updated,encoding='utf8')
                file=target
        raw=file.read_bytes()
        members.append({'member':name,'file':str(file),'toc':'data','sha256':p.sha(raw)})
    for name,file in sorted(prepared.items()):
        members.append({'member':name,'file':str(file),'toc':'data','sha256':p.sha(file.read_bytes())})
    for file in sorted((WORK/'prepared').rglob('*.ucs')):
        members.append({'member':file.relative_to(WORK/'prepared').as_posix(),'file':str(file),
                        'toc':'locale','sha256':p.sha(file.read_bytes())})
    # AoE4 discovers the Extension through native Reflect metadata, before
    # Garrison can acquire its additive race. This is separate from garrison.json
    # and garrison/civilizations.json. Carry our own freshly cooked metadata.
    for name in ('mod.bin','mod.rrtex'):
        file=WORK/'core-members'/name
        assert file.is_file(),('Missing native carrier metadata',name)
        members.append({'member':name,'file':str(file),'toc':'info','sha256':p.sha(file.read_bytes())})
    shared=set()
    for row in attributes:
        doc=p.rgd.read(Path(row['file']).read_bytes())
        for path,name,mapping in p.refs(doc.nodes):
            if mapping.value=='ebps' and ':' not in name.value:
                shared.add(name.value)
    recipe={'schema':'garrison.civilization-build/v1','owner':PROFILE_OWNER,'race':'berbers',
            'attributes':attributes,'members':members,'dispatcher':dispatcher,
            'shared_entities':sorted(shared)}
    p.save(ROOT/'build-recipe.json',recipe)
    p.save(WORK/'audit/runtime-edits.json',{'scripts':script_edits,'unimported_scripts':skipped,
           'lossless_audio_aliases':aliases,'omitted_playable_members':omitted,
           'omitted_decoded_bytes':sum(x['bytes'] for x in omitted),
           'data_ai_records':'preserved original; excluded from human-only pilot to avoid global stock AI overrides',
           'native_audio_route':'disabled; accepted external PCM route explicitly imported',
           'shared_entities':sorted(shared)})
    print('RECIPE',len(attributes),'attributes',len(members),'resources;',len(aliases),'audio aliases;',
          sum(x['bytes'] for x in omitted),'decoded bytes excluded',flush=True)


PROFILE_OWNER=p.PROFILE['owner']
if __name__=='__main__':
    main()
