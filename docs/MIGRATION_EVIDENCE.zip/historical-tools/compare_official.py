"""Read-only comparison of installed Persia/Berbers and native launch evidence."""
import collections
import hashlib
import json
from pathlib import Path
import prepare_trial as p

AUDIT=p.ROOT/'output/dropdown-investigation'
BASE=Path.home()/'AppData/Local/Garrison'


def main():
    AUDIT.mkdir(parents=True,exist_ok=True)
    game=p.stock_game.current()
    summaries={}
    for key in ('berbers','persians_independent'):
        mod=json.loads((BASE/'library'/key/'mod.json').read_text())
        census=mod['census']
        print('MOD',key,'KEYS',list(mod),'CENSUS_KEYS',list(census))
        print('META',json.dumps({k:v for k,v in mod.items() if k!='census'},indent=2)[:11000])
        print('CENSUS_META',json.dumps({k:v for k,v in census.items() if not isinstance(v,list)},indent=2)[:6000])
        archive=Path(mod['archive'])
        rows=game.archiver.members(archive)
        p.save(AUDIT/key/'list.json',rows)
        core=[]
        for row in rows:
            member=row['path']
            selected=(member=='garrison/civilizations.json' or member.startswith(('attrib/racebps/',
                     'attrib/army/','attrib/army_slot_layout/','attrib/statemodel_schema/','attrib/codex/'))
                     or member.startswith('attrib/') and member.count('/')==1
                     or row.get('toc')=='info')
            if not selected:
                continue
            raw=game.archiver.read(archive,member)
            target=AUDIT/key/'readback'/member
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
            core.append({'member':member,'toc':row.get('toc'),'bytes':len(raw),'sha256':p.sha(raw)})
            if member.endswith('.rgd'):
                doc=p.rgd.read(raw)
                leaves=[(path,n.kind,n.value) for path,n in p.rgd.flatten(doc.nodes) if not isinstance(n.value,list)]
                p.save(target.with_suffix('.leaves.json'),leaves)
            if member.endswith('civilizations.json'):
                print('DECLARATION',key,raw.decode('utf8'))
        summaries[key]={'mod_metadata':{k:v for k,v in mod.items() if k!='census'},
                        'core_members':core,'member_count':len(rows)}
        print('CORE',key,json.dumps(core,indent=2)[:7000])
    p.save(AUDIT/'package-comparison.json',summaries)
    events=[json.loads(s) for s in (BASE/'events/31552.jsonl').read_text().splitlines() if s]
    print('EVENT_KEYS',collections.Counter(tuple(d.keys()) for d in events))
    print('EVENT_KINDS',collections.Counter(str(d.get('event',d.get('kind',d.get('type')))) for d in events))
    selected=[d for d in events if any(t in str(d).lower() for t in
              ('5fe8767','civilization','race_service','owner_retention'))]
    p.save(AUDIT/'native-civilization-events.json',selected)
    print('CIV_EVENTS',len(selected))
    for event in selected:
        print(json.dumps(event)[:3500])


if __name__=='__main__':
    main()
