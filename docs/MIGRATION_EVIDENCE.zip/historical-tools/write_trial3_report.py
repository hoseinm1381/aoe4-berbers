"""Write current test instructions and compact, receipt-backed handoff."""
import json,sys
import prepare_trial as p

START='''# Berbers independent civilization test — 0.1.0-trial.3

Original civilization: hosein81 and marcokistan. Original asset-specific credits,
composed models, UV fixes, voices and music are retained. Trial.2 reached a match
and displayed Tent Influence, but its images and visual routing were incomplete.
Trial.3 corrects those migration paths and adds original editable banner artwork.
This local test still needs native acceptance.

1. Close Age of Empires IV completely.
2. Import/update this ZIP in Garrison 0.1.9 and enable **Berbers** in Civilizations.
   The existing Berber trial uses the same stable bundle key; enable one version.
3. Disable the original replacement Berber package and other custom civilizations
   for the first test, then launch AoE4 through Garrison.
4. Use **Standard**, **Tuning Pack: None**, **Dark Age**, normal resources.
5. Choose **Berbers** for your human slot and a stock civilization for the opponent.
   Do not assign this unqualified trial to an AI slot.

The old Berber game mode and tuning pack are not required. Expected starting
resources are 200 Food, 200 Wood, 100 Gold and 50 Stone before spending/gathering;
one capital Town Center, six Villagers and one Scout start through the native ArmyBP.

Check the flag in the dropdown/HUD, lobby description, separate Overview bonuses,
Codex and loading artwork. No magenta image should remain on these civ surfaces.
The Berber starting capital, male Villagers and Scout must use the original custom
visual bindings. The original art set deliberately retained some stock components,
including female-villager fallback, destruction resources and shared equipment.
This trial routes that existing art; it does not create a wholly new 3D art set.

Test these in order:

1. Construct a House and Tribal Tent. Make the first alliance choice, then check
   the 100 Gold switch cost and cooldown. Open the Tent panel and inspect influence.
2. Choose each Feudal landmark in separate tests. Funduq must appear in the Tent
   panel and affect its threshold; Ribat's Mehari effect needs a separate check.
3. Train the available unique units and ordinary units; try their abilities.
   Advance through all ages and verify the actual production/upgrade menus.
4. Check landmark/building appearance, team colours, ruins/repair, custom voices
   and music. The Berber Codex display now follows the production graph.
5. Exit to the menu and start another fresh match without closing AoE4. Check
   passive bonuses, the free first alliance and UI/audio initialization again.

For diagnostics, preserve warnings.log and Garrison's launch/native events before
the next launch. Trial.3 prints `BERBERS_TRIAL3_STARTER` with actual short names and
PBG IDs, `BERBERS_TRIAL3_EXPECT` with the expected private IDs, and
`BERBERS_PILOT_STARTED version=0.1.0-trial.3`. The runtime race is
`5fe8767cca3a4e649e20c9527cf014ec:berbers`.

AI, later-age starts, Nomad, campaign, save/load, replays, multiplayer and performance
are separate unqualified gates. A successful cook/static test is not native proof.

Rollback: close AoE4 and reimport the preserved trial.2 ZIP, or disable this trial
and use the original replacement mod with its original tuning pack/game mode.
No original source, installed mod or historical package was changed.
'''

def main():
 original=p.ucs_entries((p.ROOT/'output/dropdown-fix/build/readback/en/en.ucs').read_bytes())[2]
 assert 'FUTURE KINGDOMS CREDITS:' in original
 credits='FUTURE KINGDOMS CREDITS:'+original.split('FUTURE KINGDOMS CREDITS:',1)[1]
 credits=credits.replace('\\r\\n','\n').replace('\\n','\n')
 for name in ('hossein81','marcokistan','Karyu','lammet','ForsakenCryz'):assert name in credits
 credit_note='# Original Berber credits\n\nThe following credit block is preserved verbatim in wording from the original Berber civilization description.\n\n'+credits+'\n'
 (p.ROOT/'CREDITS.md').write_text(credit_note,encoding='utf8')
 (p.ROOT/'START-HERE.md').write_text(START+'\n## Original Future Kingdoms credits\n\n'+credits+'\n',encoding='utf8')
 if '--instructions-only' in sys.argv:return
 root=p.ROOT
 check=json.loads((root/'output/trial3-audit/checks.json').read_text())
 final=json.loads((root/'output/trial3/current/trial3-verification.json').read_text())
 delivery=json.loads((root/'output/trial3/delivery-ready/delivery-receipt.json').read_text())
 prep=json.loads((root/'output/trial3-audit/preparation.json').read_text())
 report=f'''# Berber dropdown trial.3 — 2026-10-30

Current owner-test ZIP: **0.1.0-trial.3**, {delivery['zip_bytes']:,} bytes
({delivery['zip_bytes']/1_000_000:.2f} MB). Native acceptance is pending.

- [Playable ZIP](../output/trial3/delivery-ready/Berbers-Garrison-0.1.0-trial.3.zip)
- [Player test instructions](../START-HERE.md)
- [Verification receipt](../output/trial3/current/trial3-verification.json)
- [Delivery/manifest receipt](../output/trial3/delivery-ready/delivery-receipt.json)
- [Focused checks](../output/trial3-audit/checks.json)
- [Banner preview](../source/presentation/trial3/cover.png)

## Owner evidence and diagnosis

Trial.2 appeared in the native list and started a match. Screenshots showed Tent
Influence and music UI, magenta flag/loading/player-card images, provisional
civilization prose and stock-looking Malian starter units/buildings. The owner
reported **no crash** and did not try age-up, training or alliances after seeing
that start. Earlier shutdown logs are not evidence of a gameplay crash here.

The original Berber release contains custom capital, scout, male-villager and
many building/unit tier bindings. A wholly stock-looking start is therefore not
the intended representation. Some donor art is intentionally preserved in the
original: the female-villager fallback, destruction components, equipment and
shared siege/naval resources. No blanket replacement or new 3D art set was made.

The old replacement pack retained 128 stock basenames; 123 also retained their
stock PBG IDs. Owner namespace alone does not prove these collide. However, the
current official `cardinal.scar` extracts `BP_GetName(bp)` and passes that short
name back into native race-membership accessors when filling its entity/squad
caches. Stock/private copies with the same basename are ambiguous on this path.
Trial.2 logged missing springald/villager/horseman/archer/monk cache results and
no Wonder EBP; the actual callers were traced in current official source.
Trial.3 removes the short-name ambiguity. The next native test must confirm
whether this also resolves the observed art and generic cache warnings.

## Implemented changes

- 128 imported stock-named definitions now have unique `ber_` names and native
  generated IDs. The public derive/cook path allocated the IDs; full original
  custom records were retained. Typed references, every compiled variant,
  SCAR blueprint literals, voice aliases and numeric voice maps were translated.
- The RaceBP catalogue now points to Tuareg/Masmuda/available Berber cavalry
  entries and clears unavailable donor squad slots. This catalogue correction
  does not change the original build, production or research menus.
- Tent/Funduq predicates, Tent-panel sorting/labels and Mehari landmark checks
  now compare documented short names. Blueprint resolution keeps full owner names.
  Influence training events are restricted to the exact owned Berber race, and
  its Tent predicate no longer accepts another civ's shared Spirit Way type tag.
- Native flags now resolve under `ui/images`, whereas bonus icons resolve under
  `ui/icons`. Ten original vector surfaces were cooked into both required roots,
  with correct sizes, one mip and player-card alpha. `icon_small` uses the documented
  blank/native fallback. Garrison's outer package also contains a new cover.
- Real Berber dates, three-star difficulty, civilization description and bonuses
  replace implementation placeholders. Native traits 1–6 populate the Overview;
  trait 0 remains the lobby summary. Enduring Generations says the implemented
  flat +5% Health from Feudal onward, rather than the outdated stacking claim.
- Both native Codex representations now follow actual construction, production
  and upgrade records: {prep['codex']['reachable_records']} reachable records,
  {prep['codex']['producer_branches']} producer branches, {prep['codex']['unique_cards']} unique-unit cards.
  Alliance conditions remain on original records; layout still needs native review.
  Horizontal coordinates are local to each native group, matching the stock layout.
  Indirect field construction remains a distinct review surface; valid Ram/Siege
  Tower catalogue references are retained even when no building directly spawns
  their SBPs. Production menus are preserved independently of this display.
- Passive bonuses now reset between matches and clean their modifier handles;
  alliance modifier tracking and first-choice state reset as well. Existing
  Core startup paths, local speech/music scope and disabled scripted AI remain.
- Bounded starter diagnostics print actual private names/IDs and expected IDs.
- The original long-description credit block is carried in [CREDITS.md](../CREDITS.md)
  and the packaged player instructions, including hossein81, marcokistan, Karyu,
  lammet and ForsakenCryz. The new native description replaces the obsolete
  lobby instructions; it does not replace this attribution record.

## Verification and preservation

Real native carrier cook completed, followed by the supported civilization
assembler and a reviewed RaceBP/catalogue-hash graft. The final archive has {final['all_members_read_back']:,} members;
all TOCs and every extracted SHA-256 were checked. Native archive CRC/SHA-1
verification and the archive-owner check passed. Own `info` metadata is retained.

All {final['baseline_art_audio_members_byte_identical']:,} original pilot art/audio
members are byte-identical to trial.2. Across imported non-core records,
{check['unchanged_gameplay_numeric_boolean_leaves']:,} gameplay numeric/Boolean
leaves are unchanged, excluding PBG identity. Every private reference resolves,
family/ID uniqueness passes and no old owner remains in typed attributes/scripts.
The final recipe's stock references remain drawn from the previously verified
current-stock closure and existing production records.

All {len(check['lua_syntax_checked_files'])} SCAR files pass real Lua syntax loading.
The actual old Funduq predicate fails the short-name regression, and the new
Funduq/Tent predicates pass. Both passive modules pass duplicate-start,
end/setup and second-match tests against a stubbed engine boundary. This does
not simulate native mechanics. The old shared-type predicate accepts a foreign
Chinese Spirit Way in a focused regression; the new predicate rejects it, and
a foreign training event returns before touching squad/cost/group state.
All ten BC7 image surfaces were decoded and checked
for dimensions, one mip, source-pixel error, orientation and expected alpha.

ZIP CRC and packaged SGA SHA-256 verification passed. ZIP size exceeds the older
600 MB target; the owner explicitly waived size for this test. No runtime memory,
frame-time or performance claim follows from package size.

| Artifact | SHA-256 |
| --- | --- |
| Trial.3 playable ZIP | `{delivery['zip_sha256']}` |
| Trial.3 final SGA ({final['archive_bytes']:,} bytes) | `{final['archive_sha256']}` |
| Preserved trial.2 SGA | `{final['trial2_rollback_sha256']}` |

Native trial.3 import, dropdown, art, actual training/age-ups/Tents, audio,
second matches, save/load, AI, multiplayer and performance remain separate gates.
No mod was installed, launched, committed or pushed during this work. Original
E:/F: workspaces, previous ZIPs and the composed 1.0.5 input remain unchanged.

## Editable inputs and reproduction

Current SCAR: `source/trial3/scar`. Original banner SVG/PNG sources:
`source/presentation/trial3`; recipe: `tools/make_trial3_banner.py`.
Native allocation authoring records are in `authoring-library/Mods/berbers`;
the precise identity map is `output/trial3-audit/private-identities.json`.
This is still a local pilot with preserved external rebuild inputs, not a
self-contained future-modder source release. Do not mistake compiled RGDs for
complete editable geometry/audio masters.

Use Python 3.13 with the installed Garrison compiled modules plus Pillow/Lupa.
The local verified interpreter is
`C:/Users/RS/AppData/Local/Programs/Python/Python313/python.exe`.
Run from this workspace:

```text
python tools/make_trial3_banner.py
python tools/allocate_trial3_identities.py
python tools/prepare_trial3.py
python tools/check_trial3.py
garrison-core civilization validate trial3-build-recipe.json
garrison-core civilization build trial3-build-recipe.json --output FRESH_BUILD
```

The native carrier's `project/source/ui/images/garrison/berbers/presentation`
PNGs and imported `ui/icons` PNGs are retained, so its ordinary native cook
recreates the correct resource names. Never copy an icon RRTEX into the image
root without checking its internal name.

After intentionally editing a banner PNG, update both retained native source
roots before the carrier cook. The first import used `ui_assets.add_image` for
the icon root and the same PNGs under native `project/source/ui/images` for the
race images. `allocate_trial3_identities.py` reuses existing derived records and
cooks that carrier; it does not reimport changed external PNGs automatically.

Current output is `output/trial3/current`, verified with
`python tools/verify_reviewed_trial3.py`. `tools/finalize_reviewed_archetypes.py`
records the RaceBP/declaration and influence-isolation graft after the supported reviewed
build; the receipt verifies the declaration's hashes too. The lifecycle and
local-coordinate corrections are included. The earlier `build`, `finalized`,
`build-reviewed`, `delivery` and `delivery-final` folders are intermediate receipts,
superseded by `current` and `delivery-ready`. `tools/finalize_trial3.py` records the historical four-SCAR graft
and refuses to overwrite its evidence. Do not rerun that graft on a fresh build
where those changes already exist. The package writer accepts `--build`, `--delivery`,
`--version 0.1.0-trial.3 --trial3`; require a matching full verification receipt
before packaging. Keep protected prior artifacts; use a new output only for an
explicitly requested later test.

The Garrison skill was updated through the Skill Creator workflow and validates.
Its independent-civilizations reference documents metadata discovery, native image
roots, short-name/stock-override pitfalls, gameplay preservation and gate boundaries.
'''
 (root/'docs/TRIAL3_REPORT.md').write_text(report,encoding='utf8')
 print('WROTE START-HERE.md and docs/TRIAL3_REPORT.md')

if __name__=='__main__':main()
