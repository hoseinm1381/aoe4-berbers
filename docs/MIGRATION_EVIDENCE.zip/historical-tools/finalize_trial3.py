"""Apply reviewed lifecycle edits, then verify every final member and rollback."""
import copy, hashlib,json,shutil
from pathlib import Path
import prepare_trial as p
from check_native_metadata import require_metadata

def main():
 root=p.ROOT;work=root/'output/trial3/finalized'
 previous=json.loads((root/'output/trial3/build/report.json').read_text())
 trial2=json.loads((root/'output/dropdown-fix/build/report.json').read_text())
 recipe=json.loads((root/'trial3-build-recipe.json').read_text())
 changed={}
 for row in recipe['members']:
  if row['member']==recipe['dispatcher']:continue
  if previous['members'][row['member']]['sha256']!=row['sha256']:
   changed[row['member']]=Path(row['file']).read_bytes()
 allow={'scar/passive_bonus/nomadic_trade_network.scar','scar/passive_bonus/enduring_generations.scar',
        'scar/buildings/tribal_tent.scar','scar/buildings/alliance_economic_bonus.scar'}
 assert set(changed)==allow,set(changed)
 for row in recipe['attributes']:assert previous['members'][row['member']]['sha256']==row['sha256'],row['member']
 assert not work.exists(),work
 work.mkdir(parents=True)
 game=p.stock_game.current()
 generated=game.archiver.set_members(Path(previous['archive']),changed,work/'graft',toc='data')
 final=work/'berbers.sga';shutil.copyfile(generated,final)
 listing=game.archiver.run(['list',str(final),'--verify']);p.save(work/'list.json',listing)
 assert listing['archive']['name']==p.OWNER and listing['archive']['verification']['verified']
 expected=copy.deepcopy(previous['members'])
 for m,raw in changed.items():expected[m]={'toc':'data','sha256':p.sha(raw),'bytes':len(raw)}
 require_metadata(expected)
 assert expected['mod.bin']==trial2['members']['mod.bin']
 assert expected['mod.rrtex']==trial2['members']['mod.rrtex']
 actual={r['path']:r for r in listing['members']};assert set(actual)==set(expected)
 game.archiver.run(['extract',str(final),str(work/'readback'),'--filter',''])
 for m,row in expected.items():
  assert actual[m]['toc']==row['toc'],m
  assert p.sha((work/'readback'/m).read_bytes())==row['sha256'],m
 preserved_art_audio=[]
 for m,row in trial2['members'].items():
  if m.startswith(('art/','audio/')):
   assert expected[m]==row,m;preserved_art_audio.append(m)
 digest=hashlib.file_digest(final.open('rb'),'sha256').hexdigest()
 report=copy.deepcopy(previous);report.update(archive=str(final),sha256=digest,members=expected)
 p.save(work/'report.json',report)
 receipt={'version':'0.1.0-trial.3','archive':str(final),'archive_sha256':digest,
  'archive_bytes':final.stat().st_size,'all_members_read_back':len(expected),'archive_crc_sha1_verified':True,
  'native_info_metadata_preserved':True,'baseline_art_audio_members_byte_identical':len(preserved_art_audio),
  'lifecycle_finalization_allowlist':sorted(changed),'trial2_rollback_sha256':trial2['sha256'],
  'native_game_acceptance':False}
 assert hashlib.file_digest(Path(trial2['archive']).open('rb'),'sha256').hexdigest()==trial2['sha256']
 p.save(work/'trial3-verification.json',receipt);print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':main()
