"""Audit the actual prepared native data without simulating game acceptance."""
import collections
import json
import re
from pathlib import Path
import prepare_trial as p


def main():
    recipe=json.loads((p.ROOT/'build-recipe.json').read_text())
    game=p.stock_game.current()
    game.blueprint('racebps/malian')
    rows=game.archiver.members(game._connection.attributes)
    stock=collections.defaultdict(list)
    for row in rows:
        member=row['path']
        if row.get('toc')=='attrib' and member.startswith('attrib/') and member.count('/')>=2 and member.endswith('.rgd'):
            # Native typed maps include nested maps such as navigation/agent_info
            # and relic_radial_menu/relic_radial_menu, not only top-level families.
            parts=member.split('/')
            for stop in range(2,len(parts)):
                stock[('/'.join(parts[1:stop]),Path(member).stem)].append(member)
    owned={p.key(r['member']) for r in recipe['attributes'] if r['member'].count('/')>=2}
    missing_stock=set()
    stale=[]
    missing_locale=[]
    ids=collections.defaultdict(list)
    locales=p.ucs_entries((p.WORK/'prepared/en/en.ucs').read_bytes())
    reference_count=0
    stock_reference_count=0
    preserved_numeric_leaves=0
    compared_imported_attributes=0
    for row in recipe['attributes']:
        doc=p.rgd.read(Path(row['file']).read_bytes())
        baseline=p.WORK/'baseline-attributes'/row['member']
        if baseline.is_file() and row['member'].count('/')>1:
            original=p.rgd.read(baseline.read_bytes())
            def numeric(nodes):
                return {path:(n.kind,n.value) for path,n in p.rgd.flatten(nodes)
                        if n.kind in ('Float','Int','Boolean')}
            old_values,new_values=numeric(original.nodes),numeric(doc.nodes)
            assert old_values==new_values,('Imported gameplay numeric/Boolean change',row['member'])
            preserved_numeric_leaves+=len(old_values)
            compared_imported_attributes+=1
        for path,n in p.rgd.flatten(doc.nodes):
            if isinstance(n.value,str) and p.OLD in n.value:
                stale.append([row['member'],path,n.value])
            if n.kind=='LocString' and isinstance(n.value,str) and n.value.startswith('$'+p.OWNER+':'):
                if int(n.value.split(':')[-1]) not in locales:
                    missing_locale.append([row['member'],path,n.value])
            if n.key=='pbgid' and isinstance(n.value,int):
                ids[(p.family(row['member']) if row['member'].count('/')>1 else 'root',n.value)].append(row['member'])
        for path,name,mapping in p.refs(doc.nodes):
            fam=mapping.value.replace('\\','/')
            reference_count+=1
            if name.value.startswith(p.OWNER+':'):
                assert (fam,name.value.split(':',1)[1]) in owned,(row['member'],path,name.value)
            elif ':' not in name.value:
                stock_reference_count+=1
                if (fam,name.value) not in stock:
                    missing_stock.add((fam,name.value))
    duplicate_ids={str(k):sorted(set(v)) for k,v in ids.items() if len(set(v))>1}
    # The dispatcher must run under the selected Standard mode, and never load
    # the old replacement's game-mode initializer or native AI overrides.
    scripts=list((p.ROOT/'source/scar').rglob('*.scar'))
    for file in scripts:
        assert p.OLD not in file.read_text(encoding='utf8'),file
    dispatcher=(p.ROOT/'source/scar/garrison/berbers/dispatcher.scar').read_text()
    assert 'winconditions/' not in dispatcher and 'modifier_test' not in dispatcher
    assert 'StandardMode' not in dispatcher
    assert not stale and not missing_locale and not duplicate_ids,(stale,missing_locale,duplicate_ids)
    report={'schema':'berbers.pilot-audit/v1','attributes':len(recipe['attributes']),
            'typed_references':reference_count,'stock_reference_occurrences':stock_reference_count,
            'stock_inventory_members':len(rows),'unresolved_stock_references':sorted(missing_stock),
            'stale_owner_references':stale,'missing_owned_locale_ids':missing_locale,
            'duplicate_native_ids':duplicate_ids,'scripts':len(scripts),
            'imported_attributes_numeric_compared':compared_imported_attributes,
            'unchanged_imported_numeric_boolean_leaves':preserved_numeric_leaves,
            'old_game_mode_imported':False,'native_ai_qualified':False,
            'runtime_acceptance':False,'visual_acceptance':False}
    p.save(p.WORK/'audit/semantic-audit.json',report)
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
