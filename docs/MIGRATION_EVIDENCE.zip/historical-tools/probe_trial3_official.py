import prepare_trial as p
from pathlib import Path
game=p.stock_game.current()
archive=Path('E:/Games/steamapps/common/Age of Empires IV/cardinal/archives/Data.sga')
for row in game.archiver.members(archive):
 m=row['path']
 if 'annihilation' in m.lower() or 'core.scar' in m.lower() or m in ('scar/cardinal.scar','scar/winconditions/wonder.scar'):
  print(m,row.get('size'))
  if m.endswith('.scar'):
   raw=game.archiver.read(archive,m)
   dest=p.ROOT/'output/trial3-audit/official'/m;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
