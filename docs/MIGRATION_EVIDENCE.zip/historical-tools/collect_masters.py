"""Build content-addressed editable master packs from the existing resource index.

Original locations are provenance only. Restoration is relative to the new repo.
No source/rollback in the old project is modified.
"""
import argparse
import collections
import gzip
import hashlib
import json
import os
import re
import zipfile
from pathlib import Path
from runtime import ROOT, read_json, write_json

ORIGINAL = Path('E:/age of empires 4 mods/AI_Assisted_modding/Berber_future_kingdom_ai')
EXTERNAL = Path('F:/aoe_4_temp/Berber_future_kingdom_ai_20261014')
SOURCE_TYPES = {'.blend', '.png', '.tga', '.tif', '.tiff', '.jpg', '.jpeg', '.svg',
                '.wav', '.mp3', '.flac', '.ogg', '.fbx', '.obj', '.mtl', '.json',
                '.xml', '.py', '.scar', '.lua', '.md', '.txt', '.csv', '.rdo', '.burnproj',
                '.aoe4mod', '.rhka', '.rootmotion'}


def relative(path):
    path = Path(path)
    for root, prefix in [(ORIGINAL, 'original'), (EXTERNAL, 'external')]:
        try:
            return prefix + '/' + path.relative_to(root).as_posix()
        except ValueError:
            pass
    raise ValueError(f'Unreviewed source root: {path}')


def make_plan():
    index = json.loads(gzip.decompress((ORIGINAL/'tools/berber105/source-index.json.gz').read_bytes()))
    archived = {str(Path(x['path'])).lower(): x for x in index['files']}
    resources = json.loads(gzip.decompress((ORIGINAL/'tools/berber105/resource-map.json.gz').read_bytes()))['resources']
    active = read_json(ROOT/'source/baseline-members.json')
    rows = [r for r in resources if r['member'] in active]
    candidates = set()
    for row in rows:
        candidates.update(row['authoring_candidates'])
        candidates.update(row['recipe_references'])
    selected = {}
    def add(path, reason):
        path = Path(path)
        if path.suffix.lower() not in SOURCE_TYPES:
            return
        if re.search(r'(?:preview|contact_sheet|gamecamera|_front|_back|_left|_right|_top|_bottom)\.(?:png|jpg)$', path.name, re.I):
            return
        key = str(path)
        if key in selected:
            return
        old = archived.get(key.lower())
        if path.is_file():
            row = {'original': key, 'path': relative(path), 'bytes': path.stat().st_size,
                   'source': 'loose', 'reason': reason}
        elif old:
            row = {'original': key, 'path': relative(path), 'bytes': old['bytes'],
                   'source': 'archive', 'member': old['member'], 'sha256': old['sha256'], 'reason': reason}
        else:
            return
        selected[key] = row
    for path in candidates:
        add(path, 'current packaged resource authoring candidate or recipe')
    # Retain the actual editor sources and maintained native/UV/audio recipes.
    for sub in ['assets', 'tools/berber105', 'research']:
        for folder, dirs, files in os.walk(ORIGINAL/sub, followlinks=False):
            dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', 'cache')]
            for name in files:
                path = Path(folder)/name
                if sub == 'research' and path.suffix.lower() not in ('.py', '.md', '.json'):
                    continue
                add(path, 'editable editor source or retained authoring recipe')
    for sub in ['new_voices', 'new_music']:
        for path in (ORIGINAL/sub).rglob('*'):
            if path.is_file():
                add(path, 'original voice/music master')
    # Keep referenced model source companions and source image dependencies.
    for row in list(selected.values()):
        path = Path(row['original'])
        if path.suffix.lower() == '.blend':
            for neighbor in path.parent.rglob('*'):
                if neighbor.is_file() and neighbor.suffix.lower() in SOURCE_TYPES:
                    add(neighbor, 'model authoring companion')
    plan = {'source_bundle': index['bundle'], 'source_bundle_sha256': index['bundle_sha256'],
            'files': sorted(selected.values(), key=lambda x:x['path']),
            'active_resource_rows': len(rows)}
    write_json(ROOT/'output/master-plan.json', plan)
    print('MASTER PLAN', len(selected), sum(r['bytes'] for r in selected.values()),
          collections.Counter(Path(x['path']).suffix for x in selected.values()), flush=True)


def pack():
    plan = read_json(ROOT/'output/master-plan.json')
    images = ROOT/'output/blend-dependencies.json'
    if images.exists():
        dependency_rows = read_json(images)
        missing = []
        indexed = {str(Path(x['original'])).lower() for x in plan['files']}
        archived_doc = json.loads(gzip.decompress((ORIGINAL/'tools/berber105/source-index.json.gz').read_bytes()))
        archived = {str(Path(x['path'])).lower():x for x in archived_doc['files']}
        for blend in dependency_rows:
            for image in blend['images']:
                if image['packed'] or image['source'] in ('GENERATED', 'VIEWER'):
                    continue
                path = Path(image['path'])
                if str(path).lower() in indexed:
                    continue
                old = archived.get(str(path).lower())
                if path.is_file():
                    row = {'original':str(path), 'path':relative(path), 'source':'loose', 'bytes':path.stat().st_size, 'reason':'Blender external image dependency'}
                elif old:
                    row = {'original':str(path), 'path':relative(path), 'source':'archive', 'member':old['member'], 'sha256':old['sha256'], 'bytes':old['bytes'], 'reason':'Blender external image dependency'}
                else:
                    missing.append({'blend':blend['path'], **image})
                    continue
                plan['files'].append(row); indexed.add(str(path).lower())
        write_json(ROOT/'docs/MASTER_DEPENDENCY_AUDIT.json', {'blends_inspected':len(dependency_rows),'unresolved_images':missing})
        assert not missing, f'{len(missing)} unresolved Blender images'
    packs = {}
    for label in ['art', 'audio', 'recipes']:
        target = ROOT/'inputs'/('Berbers-editable-'+label+'.zip')
        assert not target.exists(), target
        packs[label] = zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6)
    seen = collections.defaultdict(set)
    result = []
    with zipfile.ZipFile(plan['source_bundle']) as old:
        for row in sorted(plan['files'], key=lambda x:x['path']):
            raw = Path(row['original']).read_bytes() if row['source']=='loose' else old.read(row['member'])
            digest = hashlib.sha256(raw).hexdigest()
            assert len(raw) == row['bytes'], row['original']
            if 'sha256' in row:
                assert digest == row['sha256'], row['original']
            suffix = Path(row['path']).suffix.lower()
            label = 'audio' if suffix in ('.wav','.mp3','.flac','.ogg') else 'art' if suffix in ('.blend','.png','.tga','.tif','.tiff','.jpg','.jpeg','.svg','.fbx','.obj','.mtl','.rhka','.rootmotion') else 'recipes'
            if digest not in seen[label]:
                packs[label].writestr('blobs/'+digest,raw); seen[label].add(digest)
            result.append({'path':row['path'], 'original':row['original'], 'bytes':len(raw),
                           'sha256':digest,'pack':'Berbers-editable-'+label+'.zip','member':'blobs/'+digest,'reason':row['reason']})
    for pack in packs.values():
        pack.close()
    write_json(ROOT/'source/master-index.json', {'schema':'berbers.editable-masters/v1','files':result,
               'note':'Exact original authoring sources. Historical absolute paths are relocated on restore; native package inputs preserve final UV/speech fixes independently.'})
    print('MASTER PACKS COMPLETE',len(result), {k:len(v) for k,v in seen.items()}, flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['plan','pack']);args=parser.parse_args()
    make_plan() if args.action=='plan' else pack()
