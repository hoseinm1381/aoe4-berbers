import prepare_trial as p
base=p.ROOT/'output/dropdown-fix/build/readback'
f=next((base/'attrib/codex').rglob('*.rgd'));d=p.rgd.read(f.read_bytes())
tree=p.rgd.find(d.nodes,'default/codex_bag/tech_tree')
for i,g in enumerate(tree.value):
 items=p.child(g,'items').value
 print(i,p.child(g,'background_template').value,'x',[p.child(it,'x_position').value for it in items])
