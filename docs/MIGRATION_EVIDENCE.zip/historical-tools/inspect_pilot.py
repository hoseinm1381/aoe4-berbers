"""Read the frozen Berber inputs and installed stock data for the dropdown pilot."""
from pathlib import Path
import collections
import hashlib
import inspect
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
EXT = Path.home() / 'AppData/Roaming/Blender Foundation/Blender/5.2/extensions/raw_githubusercontent_com/garrison'
sys.path.insert(0, str(EXT))
from garrison_shared import rgd, stock_game


def leaves(raw):
    return [(p, n.kind, n.value) for p, n in rgd.flatten(rgd.read(raw).nodes)
            if not isinstance(n.value, list)]


def main():
    audit = ROOT / 'output/pilot/audit'
    base = ROOT / 'output/pilot/baseline-attributes'
    files = sorted(base.rglob('*.rgd'))
    names = collections.defaultdict(list)
    maps = collections.Counter()
    special = {}
    for p in files:
        rel = p.relative_to(base).as_posix()
        if rel.count('/') >= 2:
            names[(rel.split('/')[1], p.stem)].append(rel)
        rows = leaves(p.read_bytes())
        for path, kind, value in rows:
            if path.endswith('/$PBGMAP'):
                maps[value] += 1
        if any(x in rel for x in ('normal_malian', 'unit_villager_1_mal', 'building_town_center_capital_mal')) or rel.count('/') == 1:
            special[rel] = rows
    (audit/'baseline-core-leaves.json').write_text(json.dumps(special, indent=2), encoding='utf8')
    print('ATTRIBUTES', len(files))
    print('DUPLICATE_FAMILY_NAMES', {str(k): v for k, v in names.items() if len(v)>1})
    print('TYPED_MAPS', maps)
    print('STARTER_MEMBERS', list(special))
    game = stock_game.current()
    for key in ('racebps/malian', 'statemodel_schema/malian', 'statemodel_schema/player',
                'statemodel_schema/generic_player', 'codex/malian'):
        try:
            raw = game.blueprint(key)
            dest = audit/'stock'/f'{key}.rgd'
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(raw)
            rows = leaves(raw)
            (dest.with_suffix('.leaves.json')).write_text(json.dumps(rows,indent=2),encoding='utf8')
            print('STOCK', key, len(raw), 'tables', rgd.tables(rgd.read(raw).nodes))
            if key.startswith('racebps'):
                print('RACE_LINKS', [r for r in rows if any(x in r[0] for x in ('/army/', '/statemodel_schema/', '/default_army_slot_layout/'))])
        except Exception as exc:
            print('STOCK_UNAVAILABLE', key, type(exc).__name__, str(exc)[:250])
    print('GAME_FIELDS', [(k, str(v)[:180]) for k,v in vars(game).items() if k!='_blueprints'])


if __name__ == '__main__':
    main()
