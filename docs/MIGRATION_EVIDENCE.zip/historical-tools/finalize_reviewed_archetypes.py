"""Publish only the reviewed RaceBP catalogue correction into a fresh archive."""
import copy,hashlib,json,shutil,sys
from pathlib import Path
import prepare_trial as p

def main():
 root=p.ROOT;previous=json.loads((root/'output/trial3/build-reviewed/report.json').read_text())
 recipe=json.loads((root/'trial3-build-recipe.json').read_text())
 work=root/'output/trial3/current'
 if work.exists():
  assert '--refresh-unreleased' in sys.argv,'Refusing to overwrite without explicit unreleased refresh'
  assert not (root/'output/trial3/delivery-final/delivery-receipt.json').exists(),'Already delivered: use a new trial'
  p.save(root/'output/trial3-audit/catalogue-before-construction-review.json',json.loads((work/'report.json').read_text()))
  graft=work/('reviewed-graft-'+p.sha((root/'trial3-build-recipe.json').read_bytes())[:10])
 else:
  work.mkdir(parents=True);graft=work
 changes={r['member']:Path(r['file']).read_bytes() for r in recipe['attributes'] if r['sha256']!=previous['members'][r['member']]['sha256']}
 assert set(changes)=={'attrib/racebps/berbers.rgd'},set(changes)
 data_changes={}
 for r in recipe['members']:
  if r['member']==recipe['dispatcher']:continue
  if previous['members'][r['member']]['sha256']!=r['sha256']:data_changes[r['member']]=Path(r['file']).read_bytes()
 assert set(data_changes)<={'scar/inflence_system.scar'},set(data_changes)
 decl=json.loads((root/'output/trial3/build-reviewed/readback/garrison/civilizations.json').read_text())
 assert decl['races'][0]['member']=='attrib/racebps/berbers.rgd' and len(decl['races'])==1
 decl['races'][0]['sha256']=p.sha(changes['attrib/racebps/berbers.rgd'])
 declared=(json.dumps(decl,indent=2)+'\n').encode('utf8')
 game=p.stock_game.current()
 first=game.archiver.set_members(Path(previous['archive']),changes,graft/'attrib-graft',toc='attrib')
 data_changes['garrison/civilizations.json']=declared
 second=game.archiver.set_members(first,data_changes,graft/'declaration-graft',toc='data')
 final=work/'berbers.sga';shutil.copyfile(second,final)
 report=copy.deepcopy(previous);expected=report['members']
 for m,raw in changes.items():expected[m]={'toc':'attrib','bytes':len(raw),'sha256':p.sha(raw)}
 for m,raw in data_changes.items():expected[m]={'toc':'data','bytes':len(raw),'sha256':p.sha(raw)}
 report.update(archive=str(final),sha256=hashlib.file_digest(final.open('rb'),'sha256').hexdigest())
 report['archetype_finalization']={'source_sha256':previous['sha256'],'allowlist':sorted(changes)+sorted(data_changes)}
 readback=graft/'readback'
 assert not readback.exists(),readback
 game.archiver.run(['extract',str(final),str(readback),'--filter',''])
 report['readback']=str(readback)
 p.save(work/'report.json',report)
 print('RACE CATALOGUE AND HASH DECLARATION UPDATED',report['sha256'],flush=True)

if __name__=='__main__':main()
