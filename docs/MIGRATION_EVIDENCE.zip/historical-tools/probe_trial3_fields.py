import json, inspect
import prepare_trial as p
from garrison_shared import ui_assets, mod_bundle
base=p.ROOT/'output/dropdown-fix/build/readback'
for fam in ('racebps','army','codex'):
 for f in (base/'attrib'/fam).rglob('*.rgd'):
  doc=p.rgd.read(f.read_bytes())
  out=[]
  for path,n in p.rgd.flatten(doc.nodes):
   if path.startswith('default/') and not isinstance(n.value,list) and (fam=='racebps' or (fam=='army' and '/ui/' in path) or (fam=='codex' and ('tech_tree/group/items/item/' in path or 'root_item' in path))):out.append((path,n.kind,n.value))
  p.save(p.ROOT/'output/trial3-audit'/('fields-'+fam+'.json'),out)
  print(fam,json.dumps(out[:35],indent=2))
print('UIFUNCS',[(k,str(inspect.signature(v))) for k,v in vars(ui_assets).items() if inspect.isfunction(v)])
print('PACKAGE',inspect.signature(mod_bundle.write_package))
