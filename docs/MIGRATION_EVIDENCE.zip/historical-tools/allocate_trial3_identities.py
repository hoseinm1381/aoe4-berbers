"""Use the installed public derive/cook path to allocate independent PBG IDs."""
import json, subprocess
import prepare_trial as p
from garrison_shared import mod_project

PROJECT=p.ROOT/'authoring-library/Mods/berbers'
def main():
    rows=json.loads((p.ROOT/'output/trial3-audit/stock-identity-collisions.json').read_text())
    existing=json.loads((PROJECT/'mod-project.json').read_text())
    have={(r['family'],r['name']) for r in existing['derived_blueprints']}
    for row in rows:
        fam,name=p.key(row['member'])
        new='ber_'+name
        if (fam,new) not in have:
            result=mod_project.derive_blueprint(PROJECT,row['stock_member'][7:-4],new)
            print('DERIVED',fam,new,flush=True)
        row['new_name']=new
    p.save(p.ROOT/'output/trial3-audit/private-identity-plan.json',rows)
    args=[str(p.EXT/'bin/core/garrison-core.exe'),'mod-project','cook','--project',str(PROJECT),
          '--editor','E:/Games/steamapps/common/Age of Empires IV/EssenceEditor.exe']
    result=subprocess.run(args,capture_output=True,text=True)
    (p.ROOT/'output/trial3-audit/identity-cook.log').write_text(result.stdout+'\n'+result.stderr)
    assert result.returncode==0,result.stderr[-3000:]
    game=p.stock_game.current()
    archive=PROJECT/'dist/berbers.sga'
    members=game.archiver.members(archive)
    for row in rows:
        fam,_=p.key(row['member'])
        candidates=[r['path'] for r in members if r['toc']=='attrib' and p.key(r['path'])==(fam,row['new_name'])]
        assert len(candidates)==1,(fam,row['new_name'],candidates)
        doc=p.rgd.read(game.archiver.read(archive,candidates[0]))
        row['new_id']=p.rgd.find(doc.nodes,'default/pbgid').value
        row['native_carrier_member']=candidates[0]
        assert row['new_id']!=row['stock_id']
    assert len({r['new_id'] for r in rows})==len(rows)
    p.save(p.ROOT/'output/trial3-audit/private-identities.json',rows)
    print('ALLOCATED',len(rows),flush=True)

if __name__=='__main__':main()
