import json
from pathlib import Path
import prepare_trial as p
r=json.loads((p.ROOT/'trial3-build-recipe.json').read_text())
for row in r['attributes']:
 if row['member'].startswith('attrib/racebps/'):
  d=p.rgd.read(Path(row['file']).read_bytes())
  print('ARCHETYPES',json.dumps([(q,n.value,mp.value) for q,n,mp in p.refs(d.nodes) if q.startswith('default/') and '/blueprint_archetypes/' in q],indent=2))
