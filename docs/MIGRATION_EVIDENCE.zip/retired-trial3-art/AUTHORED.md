# Berber trial.3 banner sources

Original vector artwork: Maghrebi gate, dunes and geometric star on green/gold/crimson.
This is a test-civilization graphic, not an asserted historical flag.
Edit the SVGs or tools/make_trial3_banner.py. PNGs are UI-cook inputs.
The loading card alpha fade is generated in the recipe after rasterization.
